import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Lazy GoogleGenAI client
let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!geminiClient) {
    const key = (process.env.GEMINI_API_KEY || '').trim();
    geminiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  }
  return geminiClient;
}

// =========================================================================
// FIX: KIỂM TRA API KEY CHÍNH XÁC (chống lỗi "đã có key nhưng vẫn báo Off")
// - Loại bỏ khoảng trắng thừa (trim) trước khi kiểm tra.
// - Loại bỏ các giá trị placeholder/giả (ví dụ "your_api_key_here", "xxx"...).
// - Trả kèm "preview" (vài ký tự đầu/cuối) để người dùng tự đối chiếu đúng key
//   họ vừa dán vào .env, thay vì chỉ có on/off không rõ nguyên nhân.
// =========================================================================
const PLACEHOLDER_PATTERNS = [
  /^your[_-]?api[_-]?key/i,
  /^xxx+$/i,
  /^changeme$/i,
  /^replace[_-]?me$/i,
  /^example$/i,
  /^dummy$/i,
  /^test$/i,
  /^<.*>$/,
  /^\.\.\.$/
];

function isRealKey(raw: string | undefined): boolean {
  const value = (raw || '').trim();
  if (!value) return false;
  if (PLACEHOLDER_PATTERNS.some((re) => re.test(value))) return false;
  return true;
}

function maskKey(raw: string | undefined): string | null {
  const value = (raw || '').trim();
  if (!value) return null;
  if (value.length <= 8) return `${value[0] || ''}***`;
  return `${value.slice(0, 4)}...${value.slice(-4)}`;
}

const PROVIDER_ENV_MAP: Record<string, string> = {
  gemini: 'GEMINI_API_KEY',
  groq: 'GROQ_API_KEY',
  openrouter: 'OPENROUTER_API_KEY',
  deepseek: 'DEEPSEEK_API_KEY',
  openai: 'OPENAI_API_KEY',
  tavily: 'TAVILY_API_KEY',
  assemblyai: 'ASSEMBLYAI_API_KEY',
  discord: 'DISCORD_BOT_TOKEN',
  n8n: 'N8N_WEBHOOK_URL'
};

// 1. Status endpoint: Check configured AI providers (LUÔN đọc process.env trực tiếp
// tại thời điểm gọi -> phản ánh đúng "thời gian thực", không cache).
app.get('/api/ai/status', (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');

  const status: Record<string, boolean> = {};
  const details: Record<string, { configured: boolean; preview: string | null; envVar: string }> = {};

  for (const [key, envVar] of Object.entries(PROVIDER_ENV_MAP)) {
    const raw = process.env[envVar];
    const configured = isRealKey(raw);
    status[key] = configured;
    details[key] = {
      configured,
      preview: configured ? maskKey(raw) : null,
      envVar
    };
  }

  res.json({ success: true, providers: status, details, checkedAt: new Date().toISOString() });
});

// 2. AI Script Generation & Video Idea Engine
app.post('/api/ai/generate-script', async (req, res) => {
  try {
    const {
      topic = 'Video sáng tạo',
      videoTitle = '',
      targetDuration = 30,
      tone = 'hấp dẫn, cuốn hút',
      provider = 'gemini',
      customPrompt = ''
    } = req.body;

    const systemPrompt = `Bạn là chuyên gia biên kịch video ngắn (Shorts, Reels, TikTok) và video dài chuyên nghiệp. Hãy viết nội dung kịch bản cho video có tiêu đề "${videoTitle || topic}", chủ đề "${topic}", thời lượng dự kiến khoảng ${targetDuration} giây, với phong cách "${tone}". ${customPrompt ? `Yêu cầu thêm: ${customPrompt}` : ''}.
Hãy trả về kết quả định dạng JSON với cấu trúc:
{
  "catchyTitle": "Tiêu đề video cực cuốn hút",
  "hook": "Câu giật tít giữ chân người xem trong 3 giây đầu",
  "script": "Nội dung lời thoại hoặc thuyết minh hoàn chỉnh bằng tiếng Việt vừa vặn với thời lượng ${targetDuration} giây",
  "subtitles": "Nội dung tóm tắt để hiển thị phụ đề",
  "hashtags": ["#tag1", "#tag2", "#tag3"]
}`;

    // Provider 1: Gemini (Default / Primary)
    if (provider === 'gemini' || (!isRealKey(process.env.GROQ_API_KEY) && !isRealKey(process.env.OPENAI_API_KEY) && !isRealKey(process.env.DEEPSEEK_API_KEY))) {
      try {
        if (isRealKey(process.env.GEMINI_API_KEY)) {
          const ai = getGeminiClient();
          const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: systemPrompt,
            config: {
              responseMimeType: 'application/json',
              temperature: 0.7
            }
          });
          const text = response.text || '{}';
          const parsed = JSON.parse(text);
          return res.json({ success: true, data: parsed, provider: 'gemini' });
        }
      } catch (err: unknown) {
        console.warn('Gemini generate error, trying fallback if available:', err);
      }
    }

    // Provider 2: Groq (Ultra-fast LLM)
    if ((provider === 'groq' || !res.headersSent) && isRealKey(process.env.GROQ_API_KEY)) {
      try {
        const groqResp = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.GROQ_API_KEY}`
          },
          body: JSON.stringify({
            model: 'llama-3.3-70b-versatile',
            messages: [
              { role: 'system', content: 'Bạn là chuyên gia biên kịch video. Hãy luôn phản hồi JSON hợp lệ.' },
              { role: 'user', content: systemPrompt }
            ],
            response_format: { type: 'json_object' },
            temperature: 0.7
          })
        });
        if (groqResp.ok) {
          const groqData = await groqResp.json();
          const content = groqData.choices?.[0]?.message?.content || '{}';
          const parsed = JSON.parse(content);
          return res.json({ success: true, data: parsed, provider: 'groq' });
        }
      } catch (e) {
        console.warn('Groq error:', e);
      }
    }

    // Provider 3: DeepSeek
    if ((provider === 'deepseek' || !res.headersSent) && isRealKey(process.env.DEEPSEEK_API_KEY)) {
      try {
        const dsResp = await fetch('https://api.deepseek.com/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.DEEPSEEK_API_KEY}`
          },
          body: JSON.stringify({
            model: 'deepseek-chat',
            messages: [
              { role: 'system', content: 'Bạn là chuyên gia biên kịch video. Hãy trả về JSON hợp lệ.' },
              { role: 'user', content: systemPrompt }
            ],
            response_format: { type: 'json_object' },
            temperature: 0.7
          })
        });
        if (dsResp.ok) {
          const dsData = await dsResp.json();
          const content = dsData.choices?.[0]?.message?.content || '{}';
          const parsed = JSON.parse(content);
          return res.json({ success: true, data: parsed, provider: 'deepseek' });
        }
      } catch (e) {
        console.warn('DeepSeek error:', e);
      }
    }

    // Provider 4: OpenAI
    if ((provider === 'openai' || !res.headersSent) && isRealKey(process.env.OPENAI_API_KEY)) {
      try {
        const oaiResp = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
          },
          body: JSON.stringify({
            model: 'gpt-4o-mini',
            messages: [
              { role: 'system', content: 'Bạn là chuyên gia biên kịch video. Luôn trả về JSON.' },
              { role: 'user', content: systemPrompt }
            ],
            response_format: { type: 'json_object' }
          })
        });
        if (oaiResp.ok) {
          const oaiData = await oaiResp.json();
          const content = oaiData.choices?.[0]?.message?.content || '{}';
          const parsed = JSON.parse(content);
          return res.json({ success: true, data: parsed, provider: 'openai' });
        }
      } catch (e) {
        console.warn('OpenAI error:', e);
      }
    }

    // Provider 5: OpenRouter
    if ((provider === 'openrouter' || !res.headersSent) && isRealKey(process.env.OPENROUTER_API_KEY)) {
      try {
        const orResp = await fetch('https://openrouter.ai/api/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.OPENROUTER_API_KEY}`
          },
          body: JSON.stringify({
            model: 'deepseek/deepseek-chat',
            messages: [{ role: 'user', content: systemPrompt }],
            response_format: { type: 'json_object' }
          })
        });
        if (orResp.ok) {
          const orData = await orResp.json();
          const content = orData.choices?.[0]?.message?.content || '{}';
          const parsed = JSON.parse(content);
          return res.json({ success: true, data: parsed, provider: 'openrouter' });
        }
      } catch (e) {
        console.warn('OpenRouter error:', e);
      }
    }

    // Fallback template if no external API responded
    return res.json({
      success: true,
      data: {
        catchyTitle: `Bí Quyết Về ${topic} Mà Bạn Chưa Biết!`,
        hook: `Dừng lại 3 giây! Bạn đã biết điều này về ${topic} chưa?`,
        script: `Chào bạn! Trong video hôm nay, chúng ta sẽ cùng khám phá những khoảnh khắc và thông tin thú vị nhất về ${topic}. Hãy cùng theo dõi đến hết video ngay nhé!`,
        subtitles: `Khám phá những điều thú vị về ${topic}`,
        hashtags: ['#CineForge', '#VideoViral', '#SangTaoNoiDung']
      },
      provider: 'fallback'
    });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Unknown error';
    console.error('API /api/ai/generate-script failed:', msg);
    res.status(500).json({ success: false, error: msg });
  }
});

// 3. Tavily AI Real-time Web Search & Trend Research
app.post('/api/ai/tavily-search', async (req, res) => {
  try {
    const { query = 'xu hướng video hot tiktok việt nam' } = req.body;
    const apiKey = process.env.TAVILY_API_KEY;
    if (!isRealKey(apiKey)) {
      return res.status(400).json({
        success: false,
        error: 'TAVILY_API_KEY chưa được thiết lập hoặc đang là giá trị mẫu (placeholder). Vào bảng trạng thái API để kiểm tra lại.'
      });
    }

    const response = await fetch('https://api.tavily.com/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        api_key: apiKey,
        query: query,
        search_depth: 'basic',
        include_answer: true,
        max_results: 5
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      return res.status(response.status).json({ success: false, error: errText });
    }

    const data = await response.json();
    res.json({ success: true, data });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ success: false, error: msg });
  }
});

// 4. AssemblyAI Speech-to-Text (Transcription)
app.post('/api/ai/transcribe', async (req, res) => {
  try {
    const { audioUrl } = req.body;
    const apiKey = process.env.ASSEMBLYAI_API_KEY;
    if (!isRealKey(apiKey)) {
      return res.status(400).json({
        success: false,
        error: 'ASSEMBLYAI_API_KEY chưa được thiết lập hoặc đang là giá trị mẫu (placeholder).'
      });
    }
    if (!audioUrl) {
      return res.status(400).json({
        success: false,
        error: 'Vui lòng cung cấp URL âm thanh/video để phiên âm.'
      });
    }

    const submitResp = await fetch('https://api.assemblyai.com/v2/transcript', {
      method: 'POST',
      headers: {
        'authorization': apiKey,
        'content-type': 'application/json'
      },
      body: JSON.stringify({
        audio_url: audioUrl,
        language_detection: true
      })
    });

    const submitData = await submitResp.json();
    if (!submitResp.ok) {
      return res.status(submitResp.status).json({ success: false, error: submitData.error || 'AssemblyAI submit failed' });
    }

    res.json({
      success: true,
      transcriptId: submitData.id,
      status: submitData.status,
      text: submitData.text || 'Đang xử lý phiên âm âm thanh...'
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ success: false, error: msg });
  }
});

// 5. Automation Webhook Trigger (n8n Webhook)
app.post('/api/ai/trigger-n8n', async (req, res) => {
  try {
    const webhookUrl = process.env.N8N_WEBHOOK_URL;
    if (!isRealKey(webhookUrl)) {
      return res.status(400).json({
        success: false,
        error: 'N8N_WEBHOOK_URL chưa được cấu hình hoặc đang là giá trị mẫu (placeholder).'
      });
    }
    const payload = req.body || {};
    const n8nResp = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        source: 'CineForge Video Studio',
        timestamp: new Date().toISOString(),
        ...payload
      })
    });
    const responseText = await n8nResp.text();
    res.json({
      success: n8nResp.ok,
      status: n8nResp.status,
      response: responseText
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ success: false, error: msg });
  }
});

// 6. Discord Notification Dispatch
app.post('/api/ai/discord-notify', async (req, res) => {
  try {
    const token = process.env.DISCORD_BOT_TOKEN;
    const { message, channelId } = req.body;
    if (!isRealKey(token)) {
      return res.status(400).json({
        success: false,
        error: 'DISCORD_BOT_TOKEN chưa được cấu hình hoặc đang là giá trị mẫu (placeholder).'
      });
    }
    if (!channelId) {
      return res.status(400).json({
        success: false,
        error: 'Vui lòng cung cấp Discord Channel ID.'
      });
    }

    const discordResp = await fetch(`https://discord.com/api/v10/channels/${channelId}/messages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bot ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        content: message || '🎬 CineForge Video Studio: Video đã được biên tập thành công!'
      })
    });
    const data = await discordResp.json();
    res.json({ success: discordResp.ok, data });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ success: false, error: msg });
  }
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server CineForge Video Studio running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
