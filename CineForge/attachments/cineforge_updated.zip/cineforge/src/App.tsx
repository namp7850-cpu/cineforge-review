import { useState, useRef } from 'react';
import { StepId, VideoItem, AudioSettings, VideoEditSettings, RenderResult } from './types';
import { SAMPLE_VIDEOS } from './lib/sampleVideos';
import { Navbar } from './components/Navbar';
import { Step1Import } from './components/Step1Import';
import { Step2Decision } from './components/Step2Decision';
import { Step3Edit } from './components/Step3Edit';
import { Step4Export } from './components/Step4Export';
import { Step5PythonPipeline } from './components/Step5PythonPipeline';
import { AIModal } from './components/AIModal';
import { DomainSetupModal } from './components/DomainSetupModal';

export default function App() {
  const [currentStep, setCurrentStep] = useState<StepId>('IMPORT');

  // Video state (default to first sample video so preview is immediate)
  const [selectedVideo, setSelectedVideo] = useState<VideoItem | null>(SAMPLE_VIDEOS[0]);

  // Audio settings
  const [audioSettings, setAudioSettings] = useState<AudioSettings>({
    originalVideoVolume: 1.0,
    bgmVolume: 0.3,
    voiceoverVolume: 1.0,
    sfxVolume: 0.8,
    enableOriginalAudio: true,
    bgmTrackId: 'lofi',
    bgmTitle: 'Lo-Fi Chill Sunset',
    enableVoiceover: false,
    voiceoverText: 'Chào mừng bạn đến với video được biên tập cùng CineForge Studio!',
    voiceoverLang: 'vi-VN',
    voiceoverAccent: 'natural',
    voiceoverPitch: 1.0,
    voiceoverSpeed: 1.0,
    autoDucking: true,
    normalizeAudio: true,
    sampleRate: 48000,
    audioBitrate: '192k'
  });

  // Video edit settings (Defaults to 100% full duration of selected video)
  const [editSettings, setEditSettings] = useState<VideoEditSettings>({
    trimStart: 0,
    trimEnd: SAMPLE_VIDEOS[0].duration, // Gán 100% thời lượng ban đầu
    colorFilter: 'normal',
    brightness: 1.0,
    contrast: 1.0,
    saturation: 1.0,
    playbackSpeed: 1.0,
    overlayText: '',
    textPosition: 'top',
    textColor: '#ffffff',
    textBgColor: 'rgba(0, 0, 0, 0.75)',
    textSize: 22,
    enableSubtitles: false,
    subtitlesScript: '',
    aspectRatio: '16:9',
    // Thương hiệu / watermark chống ăn cắp nội dung — để trống ban đầu,
    // người dùng nhập ở Bước 3 (hoặc Claude sẽ hỏi tên cụ thể trước khi xuất).
    brandName1: '',
    enableBrandName1: true,
    brandName2: '',
    enableBrandName2: true
  });

  // Render Result state
  const [renderResult, setRenderResult] = useState<RenderResult>({
    isRendering: false,
    progress: 0,
    statusMessage: 'Chưa xuất video',
    exportedUrl: null,
    exportedBlob: null,
    exportedFilename: '',
    exportedDuration: 0,
    exportedSize: '0 MB',
    hasAudio: false,
    audioDetails: ''
  });

  // Modal states
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [isDomainModalOpen, setIsDomainModalOpen] = useState(false);

  // Global video reference
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // =========================================================================
  // FIX ĐIỀU PHỐI DỮ LIỆU: KHI CHỌN VIDEO, TRIMEND MẶC ĐỊNH BẰNG 100% VIDEO.DURATION
  // =========================================================================
  const handleSelectVideo = (video: VideoItem) => {
    setSelectedVideo(video);
    // Khi chọn bất kỳ video nào, trimEnd được gán mặc định bằng đúng video.duration
    // của video gốc, đảm bảo xuất trọn vẹn 100% thời lượng gốc mà không bị giới hạn thời gian.
    setEditSettings((prev) => ({
      ...prev,
      trimStart: 0,
      trimEnd: video.duration,
      aspectRatio: video.aspectRatio
    }));
  };

  const handleApplyAiScript = (script: string, subtitles: string, title?: string) => {
    setAudioSettings((prev) => ({
      ...prev,
      voiceoverText: script,
      enableVoiceover: true
    }));
    setEditSettings((prev) => ({
      ...prev,
      subtitlesScript: subtitles,
      overlayText: title || prev.overlayText,
      enableSubtitles: true
    }));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Navbar with step navigation */}
      <Navbar
        currentStep={currentStep}
        onSelectStep={(step) => setCurrentStep(step)}
        hasInputVideo={!!selectedVideo}
        hasExportedVideo={!!renderResult.exportedUrl}
        onOpenDomainModal={() => setIsDomainModalOpen(true)}
        onOpenAiModal={() => setIsAiModalOpen(true)}
      />

      {/* Main Studio Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {currentStep === 'IMPORT' && (
          <Step1Import
            selectedVideo={selectedVideo}
            onSelectVideo={handleSelectVideo}
            onGoToNextStep={() => setCurrentStep('DECISION')}
          />
        )}

        {currentStep === 'DECISION' && (
          <Step2Decision
            selectedVideo={selectedVideo}
            audioSettings={audioSettings}
            editSettings={editSettings}
            onChangeAudio={setAudioSettings}
            onChangeEdit={setEditSettings}
            onGoToNextStep={() => setCurrentStep('EDIT')}
            onGoBack={() => setCurrentStep('IMPORT')}
            onOpenAiModal={() => setIsAiModalOpen(true)}
          />
        )}

        {currentStep === 'EDIT' && (
          <Step3Edit
            selectedVideo={selectedVideo}
            audioSettings={audioSettings}
            editSettings={editSettings}
            onChangeEdit={setEditSettings}
            onGoToExport={() => setCurrentStep('EXPORT')}
            onGoBack={() => setCurrentStep('DECISION')}
            videoRef={videoRef}
          />
        )}

        {currentStep === 'EXPORT' && (
          <Step4Export
            selectedVideo={selectedVideo}
            audioSettings={audioSettings}
            editSettings={editSettings}
            renderResult={renderResult}
            onUpdateRenderResult={setRenderResult}
            videoRef={videoRef}
            onGoToPythonPipeline={() => setCurrentStep('PYTHON_PIPELINE')}
            onGoBackToEdit={() => setCurrentStep('EDIT')}
          />
        )}

        {currentStep === 'PYTHON_PIPELINE' && (
          <Step5PythonPipeline />
        )}
      </main>

      {/* AI Studio Modal (Gemini, Groq, DeepSeek, OpenAI, Tavily, AssemblyAI, n8n, Discord) */}
      <AIModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        selectedVideo={selectedVideo}
        audioSettings={audioSettings}
        editSettings={editSettings}
        onApplyScript={handleApplyAiScript}
      />

      {/* Domain Configuration Modal for thkangctv.com */}
      <DomainSetupModal
        isOpen={isDomainModalOpen}
        onClose={() => setIsDomainModalOpen(false)}
      />
    </div>
  );
}
