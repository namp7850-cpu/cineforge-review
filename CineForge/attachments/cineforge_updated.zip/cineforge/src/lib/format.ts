/**
 * Định dạng thời lượng (giây) sang dạng dễ đọc.
 * < 60s  -> "12.3s"
 * >= 60s -> "2 phút 05s" (và kèm mm:ss dạng đồng hồ khi cần)
 */
export function formatDuration(totalSeconds: number): string {
  const s = Math.max(0, totalSeconds || 0);
  if (s < 60) return `${s.toFixed(1)}s`;
  const minutes = Math.floor(s / 60);
  const seconds = Math.round(s % 60);
  return `${minutes} phút ${seconds.toString().padStart(2, '0')}s`;
}

/** Dạng đồng hồ mm:ss (hoặc h:mm:ss nếu vượt 1 giờ) */
export function formatClock(totalSeconds: number): string {
  const s = Math.max(0, Math.round(totalSeconds || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) {
    return `${h}:${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  }
  return `${m}:${sec.toString().padStart(2, '0')}`;
}
