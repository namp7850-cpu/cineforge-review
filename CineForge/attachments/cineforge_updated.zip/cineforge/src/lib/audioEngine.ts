import { AudioSettings } from '../types';

export interface BGMTrackInfo {
  id: string;
  name: string;
  genre: string;
  tempo: string;
  description: string;
  previewColor: string;
}

export const BGM_TRACKS: BGMTrackInfo[] = [
  {
    id: 'none',
    name: 'Không dùng nhạc nền',
    genre: 'Tắt BGM',
    tempo: '-',
    description: 'Chỉ dùng âm thanh gốc hoặc giọng nói',
    previewColor: 'bg-slate-700'
  },
  {
    id: 'lofi',
    name: 'Lo-Fi Chill Sunset',
    genre: 'Lo-Fi / Thư giãn',
    tempo: '80 BPM',
    description: 'Giai điệu ấm áp, êm dịu, hợp vlog đời sống & học tập',
    previewColor: 'bg-amber-600'
  },
  {
    id: 'cinematic',
    name: 'Cinematic Epic Horizon',
    genre: 'Điện ảnh / Hùng tráng',
    tempo: '110 BPM',
    description: 'Âm thanh không gian rộng lớn, trailer, du lịch',
    previewColor: 'bg-indigo-600'
  },
  {
    id: 'upbeat',
    name: 'Upbeat Tech Energy',
    genre: 'Điện tử / Năng động',
    tempo: '128 BPM',
    description: 'Nhịp điệu bắt tai, hợp review công nghệ, shorts',
    previewColor: 'bg-emerald-600'
  },
  {
    id: 'vlog',
    name: 'Acoustic Bright Day',
    genre: 'Acoustic / Vui tươi',
    tempo: '100 BPM',
    description: 'Giai điệu tươi sáng, ẩm thực, du lịch nhẹ nhàng',
    previewColor: 'bg-rose-600'
  },
  {
    id: 'dramatic',
    name: 'Dramatic Tension Beat',
    genre: 'Kịch tính / Hồi hộp',
    tempo: '90 BPM',
    description: 'Nhịp tim cao trào, câu chuyện hồi hộp',
    previewColor: 'bg-purple-600'
  },
  {
    id: 'chill',
    name: 'Deep Ambient Calm',
    genre: 'Ambient / Thiền định',
    tempo: '70 BPM',
    description: 'Âm thanh nền tĩnh lặng, podcast, phỏng vấn',
    previewColor: 'bg-cyan-600'
  },
  {
    id: 'custom',
    name: 'Tải nhạc riêng (MP3/WAV)',
    genre: 'Tùy chỉnh',
    tempo: 'Tùy biến',
    description: 'Sử dụng file âm thanh từ máy tính của bạn',
    previewColor: 'bg-pink-600'
  }
];

class AudioEngine {
  private ctx: AudioContext | null = null;
  private currentBgmNodes: { stop: () => void } | null = null;

  public getContext(): AudioContext {
    if (!this.ctx || this.ctx.state === 'closed') {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioContextClass();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  /**
   * Generates synthetic ambient/melodic BGM tracks using Web Audio API synthesis
   */
  public playSynthesizedBGM(trackId: string, volume: number = 0.5, loop = true): { stop: () => void } {
    this.stopBGM();
    if (trackId === 'none') {
      return { stop: () => {} };
    }

    const ctx = this.getContext();
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(Math.max(0.01, Math.min(1.5, volume)), ctx.currentTime);
    masterGain.connect(ctx.destination);

    const activeOscillators: OscillatorNode[] = [];
    const activeIntervals: number[] = [];

    if (trackId === 'lofi' || trackId === 'chill') {
      // Warm chords + subtle bass
      const chords = [
        [261.63, 329.63, 392.00, 493.88], // Cmaj7
        [220.00, 261.63, 329.63, 392.00], // Am7
        [174.61, 220.00, 261.63, 329.63], // Fmaj7
        [196.00, 246.94, 293.66, 349.23]  // G7
      ];
      let chordIndex = 0;

      const playChord = () => {
        if (ctx.state === 'closed') return;
        const currentChord = chords[chordIndex % chords.length];
        chordIndex++;

        currentChord.forEach(freq => {
          const osc = ctx.createOscillator();
          const noteGain = ctx.createGain();
          const filter = ctx.createBiquadFilter();
          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(800, ctx.currentTime);

          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, ctx.currentTime);

          noteGain.gain.setValueAtTime(0.001, ctx.currentTime);
          noteGain.gain.exponentialRampToValueAtTime(0.08, ctx.currentTime + 0.3);
          noteGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 2.8);

          osc.connect(filter);
          filter.connect(noteGain);
          noteGain.connect(masterGain);

          osc.start(ctx.currentTime);
          osc.stop(ctx.currentTime + 3.0);
          activeOscillators.push(osc);
        });

        // Bass root
        const bassOsc = ctx.createOscillator();
        const bassGain = ctx.createGain();
        bassOsc.type = 'sine';
        bassOsc.frequency.setValueAtTime(currentChord[0] / 2, ctx.currentTime);
        bassGain.gain.setValueAtTime(0.12, ctx.currentTime);
        bassGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 2.8);

        bassOsc.connect(bassGain);
        bassGain.connect(masterGain);
        bassOsc.start(ctx.currentTime);
        bassOsc.stop(ctx.currentTime + 3.0);
        activeOscillators.push(bassOsc);
      };

      playChord();
      if (loop) {
        const interval = window.setInterval(playChord, 3000);
        activeIntervals.push(interval);
      }
    } else if (trackId === 'upbeat' || trackId === 'vlog') {
      // Arpeggio & bright pulse
      const notes = [440, 523.25, 659.25, 783.99, 880, 783.99, 659.25, 523.25];
      let step = 0;

      const playPulse = () => {
        if (ctx.state === 'closed') return;
        const freq = notes[step % notes.length];
        step++;

        const osc = ctx.createOscillator();
        const noteGain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);

        noteGain.gain.setValueAtTime(0.001, ctx.currentTime);
        noteGain.gain.linearRampToValueAtTime(0.09, ctx.currentTime + 0.05);
        noteGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.28);

        osc.connect(noteGain);
        noteGain.connect(masterGain);

        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.3);
        activeOscillators.push(osc);
      };

      playPulse();
      if (loop) {
        const interval = window.setInterval(playPulse, 240);
        activeIntervals.push(interval);
      }
    } else {
      // Cinematic / Dramatic drone & brass swell
      const baseFreq = trackId === 'dramatic' ? 110 : 130.81; // A2 or C3
      [1, 1.5, 2, 2.5].forEach((multiplier, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const filter = ctx.createBiquadFilter();

        osc.type = idx % 2 === 0 ? 'sawtooth' : 'triangle';
        osc.frequency.setValueAtTime(baseFreq * multiplier, ctx.currentTime);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(400, ctx.currentTime);
        filter.frequency.linearRampToValueAtTime(1200, ctx.currentTime + 2.0);
        filter.frequency.linearRampToValueAtTime(400, ctx.currentTime + 4.0);

        gain.gain.setValueAtTime(0.02, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.06, ctx.currentTime + 1.5);
        gain.gain.linearRampToValueAtTime(0.02, ctx.currentTime + 3.8);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(masterGain);

        osc.start(ctx.currentTime);
        activeOscillators.push(osc);
      });
    }

    const controller = {
      stop: () => {
        activeIntervals.forEach(id => clearInterval(id));
        activeOscillators.forEach(osc => {
          try {
            osc.stop();
            osc.disconnect();
          } catch {
            // ignore if already stopped
          }
        });
        masterGain.disconnect();
      }
    };

    this.currentBgmNodes = controller;
    return controller;
  }

  public stopBGM() {
    if (this.currentBgmNodes) {
      this.currentBgmNodes.stop();
      this.currentBgmNodes = null;
    }
  }

  /**
   * Sound Effect Synthesizer
   */
  public playSFX(sfxType: 'ding' | 'whoosh' | 'pop' | 'bass_drop' | 'applause', volume = 0.8) {
    const ctx = this.getContext();
    const master = ctx.createGain();
    master.gain.setValueAtTime(volume, ctx.currentTime);
    master.connect(ctx.destination);

    if (sfxType === 'ding') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1760, ctx.currentTime); // A6
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.8);

      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.8);

      osc.connect(gain);
      gain.connect(master);
      osc.start();
      osc.stop(ctx.currentTime + 0.8);
    } else if (sfxType === 'whoosh') {
      const bufferSize = ctx.sampleRate * 0.4;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(300, ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(3000, ctx.currentTime + 0.2);
      filter.frequency.exponentialRampToValueAtTime(200, ctx.currentTime + 0.4);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.01, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.3, ctx.currentTime + 0.2);
      gain.gain.linearRampToValueAtTime(0.01, ctx.currentTime + 0.4);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(master);
      noise.start();
    } else if (sfxType === 'pop') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(400, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.1);

      gain.gain.setValueAtTime(0.4, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1);

      osc.connect(gain);
      gain.connect(master);
      osc.start();
      osc.stop(ctx.currentTime + 0.1);
    } else if (sfxType === 'bass_drop') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(150, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(35, ctx.currentTime + 1.2);

      gain.gain.setValueAtTime(0.5, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);

      osc.connect(gain);
      gain.connect(master);
      osc.start();
      osc.stop(ctx.currentTime + 1.2);
    } else {
      // Applause / Cheer (multi noise grain)
      const bufferSize = ctx.sampleRate * 1.5;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.sin((i / bufferSize) * Math.PI);
      }
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      noise.connect(gain);
      gain.connect(master);
      noise.start();
    }
  }

  /**
   * Text-to-Speech (Vietnamese & English) with pitch and rate controls
   */
  public speakText(text: string, lang = 'vi-VN', speed = 1.0, pitch = 1.0, onEnd?: () => void) {
    if (!('speechSynthesis' in window)) {
      console.warn('Speech synthesis not supported in this browser');
      if (onEnd) onEnd();
      return;
    }
    window.speechSynthesis.cancel();
    const cleanText = text.trim() || 'Xin chào! Bạn đang thử nghiệm giọng đọc AI của CineForge.';
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = lang;
    utterance.rate = Math.max(0.6, Math.min(1.8, speed));
    utterance.pitch = Math.max(0.5, Math.min(1.6, pitch));

    const voices = window.speechSynthesis.getVoices();
    const viVoice = voices.find(v => v.lang.startsWith('vi') || v.name.toLowerCase().includes('vietnam'));
    if (viVoice) {
      utterance.voice = viVoice;
    }

    if (onEnd) {
      utterance.onend = onEnd;
      utterance.onerror = onEnd;
    }
    window.speechSynthesis.speak(utterance);
  }

  public stopSpeaking() {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }

  /**
   * Test Mixed Audio Preview: Plays video sound + BGM + Voice sample together
   */
  public testMixedAudio(settings: AudioSettings, videoEl?: HTMLVideoElement | null, onFinish?: () => void) {
    this.stopBGM();
    this.stopSpeaking();
    
    // 1. Play Video Audio if video element provided
    if (videoEl && settings.enableOriginalAudio && settings.originalVideoVolume > 0) {
      videoEl.volume = Math.min(1.0, settings.originalVideoVolume);
      videoEl.muted = false;
      videoEl.currentTime = 0;
      videoEl.play().catch(() => {});
    }

    // 2. Play BGM
    if (settings.bgmTrackId !== 'none' && settings.bgmVolume > 0) {
      this.playSynthesizedBGM(settings.bgmTrackId, settings.bgmVolume * (settings.autoDucking ? 0.4 : 1.0));
    }

    // 3. Speak TTS Voice
    if (settings.enableVoiceover && settings.voiceoverVolume > 0) {
      const sampleText = settings.voiceoverText || 'Chào mừng bạn đến với video được biên tập bằng CineForge. Mọi âm thanh vẫn được giữ trọn vẹn và hoàn hảo.';
      this.speakText(
        sampleText.slice(0, 100),
        settings.voiceoverLang,
        settings.voiceoverSpeed,
        settings.voiceoverPitch,
        () => {
          setTimeout(() => {
            this.stopTestMixedAudio(videoEl);
            if (onFinish) onFinish();
          }, 1000);
        }
      );
    } else {
      // 5-second preview if no voiceover
      setTimeout(() => {
        this.stopTestMixedAudio(videoEl);
        if (onFinish) onFinish();
      }, 5000);
    }
  }

  public stopTestMixedAudio(videoEl?: HTMLVideoElement | null) {
    this.stopBGM();
    this.stopSpeaking();
    if (videoEl) {
      videoEl.pause();
    }
  }
}

export const audioEngine = new AudioEngine();
