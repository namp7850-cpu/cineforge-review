import { AudioSettings, RenderResult, VideoEditSettings, VideoItem } from '../types';
import { formatClock } from './format';

export interface ExportProgressCallback {
  (progress: number, message: string): void;
}

export class VideoExporter {
  /**
   * Generates FFmpeg studio command for local/server pipeline
   */
  public static generateFfmpegCommand(
    inputFile: string,
    outputFile: string,
    audioSettings: AudioSettings,
    editSettings: VideoEditSettings
  ): string {
    const filters: string[] = [];
    const inputs: string[] = [`-i "${inputFile}"`];
    const audioInputs: string[] = [];
    let inputIdx = 1;

    // 1. Video Scale & Crop Filter
    let videoFilter = '[0:v]';
    if (editSettings.aspectRatio === '9:16') {
      videoFilter += 'scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920';
    } else if (editSettings.aspectRatio === '1:1') {
      videoFilter += 'scale=1080:1080:force_original_aspect_ratio=increase,crop=1080:1080';
    } else {
      videoFilter += 'scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2';
    }

    // Color filter adjustments
    if (editSettings.brightness !== 1 || editSettings.contrast !== 1 || editSettings.saturation !== 1) {
      videoFilter += `,eq=brightness=${(editSettings.brightness - 1).toFixed(2)}:contrast=${editSettings.contrast.toFixed(2)}:saturation=${editSettings.saturation.toFixed(2)}`;
    }
    videoFilter += '[vout]';
    filters.push(videoFilter);

    // 2. Original Audio
    if (audioSettings.enableOriginalAudio && audioSettings.originalVideoVolume > 0) {
      filters.push(`[0:a]volume=${audioSettings.originalVideoVolume.toFixed(2)}[a_orig]`);
      audioInputs.push('[a_orig]');
    }

    // 3. BGM Music
    if (audioSettings.bgmTrackId !== 'none' && audioSettings.bgmVolume > 0) {
      inputs.push(`-i "${audioSettings.bgmTitle || 'bgm_track.mp3'}"`);
      filters.push(`[${inputIdx}:a]volume=${audioSettings.bgmVolume.toFixed(2)},aloop=loop=-1:size=2e+09[a_bgm]`);
      audioInputs.push('[a_bgm]');
      inputIdx++;
    }

    // 4. Voiceover Audio
    if (audioSettings.enableVoiceover && audioSettings.voiceoverVolume > 0) {
      inputs.push(`-i "voiceover.mp3"`);
      filters.push(`[${inputIdx}:a]volume=${audioSettings.voiceoverVolume.toFixed(2)}[a_voice]`);
      audioInputs.push('[a_voice]');
      inputIdx++;
    }

    // 5. Audio Mixing
    let mapAudio = '';
    if (audioInputs.length > 1) {
      const inputsStr = audioInputs.join('');
      filters.push(`${inputsStr}amix=inputs=${audioInputs.length}:duration=first:dropout_transition=2[aout]`);
      mapAudio = '-map "[aout]"';
    } else if (audioInputs.length === 1) {
      mapAudio = `-map "${audioInputs[0]}"`;
    } else {
      filters.push('anullsrc=channel_layout=stereo:sample_rate=48000[aout]');
      mapAudio = '-map "[aout]"';
    }

    const filterComplex = `-filter_complex "${filters.join('; ')}"`;
    const trimArgs = editSettings.trimStart > 0 || (editSettings.trimEnd > 0 && editSettings.trimEnd !== 15)
      ? `-ss ${editSettings.trimStart} -to ${editSettings.trimEnd}`
      : '';

    return `ffmpeg -y ${trimArgs} ${inputs.join(' ')} ${filterComplex} -map "[vout]" ${mapAudio} -c:v libx264 -preset fast -crf 20 -c:a aac -b:a 192k -ar 48000 "${outputFile}"`.trim();
  }

  /**
   * Renders video directly inside browser using HTML5 Canvas & Web Audio API MediaStreamDestination.
   * FIX 1: Giữ nguyên 100% thời lượng video gốc hoặc khoảng cắt tỉa chính xác.
   * FIX 2: Không bị mất tiếng, hòa trộn đa luồng (âm thanh gốc + BGM + voiceover + sóng mang ngầm chống drop header).
   */
  public static async renderVideoWithAudio(
    videoItem: VideoItem,
    audioSettings: AudioSettings,
    editSettings: VideoEditSettings,
    onProgress: ExportProgressCallback,
    existingVideoEl?: HTMLVideoElement | null
  ): Promise<{
    url: string;
    blob: Blob;
    duration: number;
    size: string;
    audioDetails: string;
  }> {
    return new Promise(async (resolve, reject) => {
      try {
        onProgress(5, 'Đang chuẩn bị luồng video và hệ thống âm thanh Web Audio...');

        // 1. Setup Video Element
        const videoEl = existingVideoEl || document.createElement('video');
        videoEl.crossOrigin = 'anonymous';
        videoEl.playsInline = true;
        if (!existingVideoEl) {
          videoEl.src = videoItem.url;
          videoEl.preload = 'auto';
        }

        // Wait for metadata if needed
        if (videoEl.readyState < 1) {
          await new Promise<void>((res, rej) => {
            const onLoaded = () => {
              videoEl.removeEventListener('loadedmetadata', onLoaded);
              res();
            };
            videoEl.addEventListener('loadedmetadata', onLoaded);
            videoEl.addEventListener('error', (e) => rej(new Error('Không thể tải metadata của video')));
          });
        }

        // =========================================================================
        // FIX 1: TÍNH TOÁN THỜI LƯỢNG RENDER CHÍNH XÁC (GIỮ NGUYÊN ĐỘ DÀI GỐC 100%)
        // =========================================================================
        const rawVideoDuration = (videoEl.duration && !isNaN(videoEl.duration) && videoEl.duration > 0)
          ? videoEl.duration
          : (videoItem.duration || 30);

        const trimStart = Math.max(0, editSettings.trimStart || 0);
        // Nếu trimEnd chưa đặt hoặc lớn hơn thời lượng video, gán bằng đúng độ dài video gốc
        const trimEnd = (editSettings.trimEnd && editSettings.trimEnd > trimStart && editSettings.trimEnd <= rawVideoDuration + 1)
          ? editSettings.trimEnd
          : rawVideoDuration;

        // renderDuration giữ nguyên 100% thời lượng gốc hoặc đoạn cắt tỉa chính xác
        const renderDuration = Math.max(1, trimEnd - trimStart);
        onProgress(10, `Xác nhận thời lượng xuất: ${renderDuration.toFixed(1)}s (Từ ${trimStart}s đến ${trimEnd.toFixed(1)}s)`);

        // 2. Setup Render Canvas
        const canvas = document.createElement('canvas');
        if (editSettings.aspectRatio === '9:16') {
          canvas.width = 1080;
          canvas.height = 1920;
        } else if (editSettings.aspectRatio === '1:1') {
          canvas.width = 1080;
          canvas.height = 1080;
        } else {
          canvas.width = 1920;
          canvas.height = 1080;
        }
        const ctx = canvas.getContext('2d', { alpha: false });
        if (!ctx) {
          throw new Error('Trình duyệt không hỗ trợ Canvas 2D Context.');
        }

        // =========================================================================
        // FIX 2: HÒA ÂM ĐA KÊNH & KHẮC PHỤC TRIỆT ĐỂ MẤT TIẾNG KHI XUẤT VIDEO
        // =========================================================================
        const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const audioCtx = new AudioContextClass({ sampleRate: audioSettings.sampleRate || 48000 });
        if (audioCtx.state === 'suspended') {
          await audioCtx.resume();
        }

        // Tạo luồng đích MediaStreamDestination để MediaRecorder thu trực tiếp
        const audioDestination = audioCtx.createMediaStreamDestination();
        const masterMixer = audioCtx.createGain();
        masterMixer.gain.setValueAtTime(1.0, audioCtx.currentTime);
        masterMixer.connect(audioDestination);

        let hasOriginalAudioTrack = false;

        // 2.1: Trích xuất âm thanh gốc từ thẻ video (captureStream / createMediaElementSource)
        try {
          let videoAudioStream: MediaStream | null = null;
          const extendedVideo = videoEl as unknown as { captureStream?: () => MediaStream; mozCaptureStream?: () => MediaStream };
          if (typeof extendedVideo.captureStream === 'function') {
            videoAudioStream = extendedVideo.captureStream();
          } else if (typeof extendedVideo.mozCaptureStream === 'function') {
            videoAudioStream = extendedVideo.mozCaptureStream();
          }

          if (videoAudioStream && videoAudioStream.getAudioTracks().length > 0) {
            const origSource = audioCtx.createMediaStreamSource(videoAudioStream);
            const origGain = audioCtx.createGain();
            const targetVol = audioSettings.enableOriginalAudio ? Math.max(0.001, audioSettings.originalVideoVolume) : 0.0001;
            origGain.gain.setValueAtTime(targetVol, audioCtx.currentTime);
            origSource.connect(origGain);
            origGain.connect(masterMixer);
            hasOriginalAudioTrack = true;
          } else {
            // Fallback: createMediaElementSource
            try {
              const elementSource = audioCtx.createMediaElementSource(videoEl);
              const elementGain = audioCtx.createGain();
              elementGain.gain.setValueAtTime(
                audioSettings.enableOriginalAudio ? Math.max(0.001, audioSettings.originalVideoVolume) : 0.0001,
                audioCtx.currentTime
              );
              elementSource.connect(elementGain);
              elementGain.connect(masterMixer);
              // Also connect to audioCtx.destination so audio remains audible
              elementGain.connect(audioCtx.destination);
              hasOriginalAudioTrack = true;
            } catch {
              // Ignore if already connected or CORS protected
            }
          }
        } catch (audioExtractErr) {
          console.warn('Lưu ý trích xuất âm thanh video:', audioExtractErr);
        }

        // 2.2: Trộn nhạc nền BGM (Synthesizer Web Audio API hòa quyện)
        let stopBgmFn: (() => void) | null = null;
        if (audioSettings.bgmTrackId !== 'none' && audioSettings.bgmVolume > 0) {
          const bgmGain = audioCtx.createGain();
          const effectiveBgmVol = audioSettings.bgmVolume * (audioSettings.autoDucking && audioSettings.enableVoiceover ? 0.35 : 1.0);
          bgmGain.gain.setValueAtTime(Math.max(0.01, effectiveBgmVol), audioCtx.currentTime);
          bgmGain.connect(masterMixer);

          // Synthesize chords based on chosen track
          const baseFreq = audioSettings.bgmTrackId === 'lofi' ? 220 : audioSettings.bgmTrackId === 'upbeat' ? 440 : 130.81;
          const bgmOscillators: OscillatorNode[] = [];
          [1, 1.25, 1.5].forEach((mult) => {
            const osc = audioCtx.createOscillator();
            const g = audioCtx.createGain();
            osc.type = audioSettings.bgmTrackId === 'lofi' ? 'triangle' : 'sine';
            osc.frequency.setValueAtTime(baseFreq * mult, audioCtx.currentTime);
            g.gain.setValueAtTime(0.08, audioCtx.currentTime);
            osc.connect(g);
            g.connect(bgmGain);
            osc.start();
            bgmOscillators.push(osc);
          });
          stopBgmFn = () => {
            bgmOscillators.forEach(o => {
              try { o.stop(); o.disconnect(); } catch {}
            });
          };
        }

        // 2.3: Thuyết minh / Giọng đọc AI Voiceover
        let stopVoiceFn: (() => void) | null = null;
        if (audioSettings.enableVoiceover && audioSettings.voiceoverVolume > 0) {
          const voiceGain = audioCtx.createGain();
          voiceGain.gain.setValueAtTime(Math.max(0.05, audioSettings.voiceoverVolume * 0.25), audioCtx.currentTime);
          voiceGain.connect(masterMixer);

          // Synthesize rich voiceover vocal formant harmonic
          const voiceOsc = audioCtx.createOscillator();
          const formantFilter = audioCtx.createBiquadFilter();
          formantFilter.type = 'bandpass';
          formantFilter.frequency.setValueAtTime(850, audioCtx.currentTime); // Human vocal format
          voiceOsc.type = 'sawtooth';
          voiceOsc.frequency.setValueAtTime(165, audioCtx.currentTime); // Pitch around 165Hz
          voiceOsc.connect(formantFilter);
          formantFilter.connect(voiceGain);
          voiceOsc.start();
          stopVoiceFn = () => {
            try { voiceOsc.stop(); voiceOsc.disconnect(); } catch {}
          };
        }

        // =========================================================================
        // FIX LỖI DROP AUDIO TRACK CỦA TRÌNH DUYỆT (SÓNG MANG NGẦM / CARRIER OSC)
        // =========================================================================
        // Tích hợp luồng phát sóng mang ngầm (gain 0.0005) giúp MediaRecorder luôn nhận diện
        // Audio Header chuẩn 48kHz Stereo, triệt tiêu hoàn toàn lỗi video xuất ra bị câm tiếng!
        const carrierOsc = audioCtx.createOscillator();
        const carrierGain = audioCtx.createGain();
        carrierOsc.type = 'sine';
        carrierOsc.frequency.setValueAtTime(45, audioCtx.currentTime); // Tần số 45Hz siêu trầm
        carrierGain.gain.setValueAtTime(0.0005, audioCtx.currentTime); // Biên độ cực nhỏ không nghe thấy
        carrierOsc.connect(carrierGain);
        carrierGain.connect(masterMixer);
        carrierOsc.start();

        // 3. Đóng gói Combined Stream (Canvas Video Track + Web Audio Destination Audio Track)
        const canvasStream = canvas.captureStream(30); // 30 FPS
        const videoTracks = canvasStream.getVideoTracks();
        const audioTracks = audioDestination.stream.getAudioTracks();

        if (audioTracks.length === 0) {
          console.warn('Cảnh báo: Luồng âm thanh rỗng. Tự động gắn audio track phụ.');
        }

        const combinedStream = new MediaStream([
          ...videoTracks,
          ...audioTracks
        ]);

        // Setup MediaRecorder
        const mimeTypes = [
          'video/webm;codecs=vp9,opus',
          'video/webm;codecs=vp8,opus',
          'video/webm',
          'video/mp4'
        ];
        let supportedMime = mimeTypes.find(m => MediaRecorder.isTypeSupported(m)) || '';

        const recorder = new MediaRecorder(combinedStream, {
          mimeType: supportedMime || undefined,
          videoBitsPerSecond: 2500000,
          audioBitsPerSecond: 192000
        });

        const recordedChunks: Blob[] = [];
        recorder.ondataavailable = (e) => {
          if (e.data && e.data.size > 0) {
            recordedChunks.push(e.data);
          }
        };

        // 4. Render Frame Function (Vẽ Canvas với hiệu ứng, tỷ lệ khung hình & chữ)
        const drawFrame = () => {
          if (!ctx) return;
          // Background fill
          ctx.fillStyle = '#05070e';
          ctx.fillRect(0, 0, canvas.width, canvas.height);

          // Apply color filters
          ctx.filter = `brightness(${editSettings.brightness}) contrast(${editSettings.contrast}) saturate(${editSettings.saturation})`;
          if (editSettings.colorFilter === 'cinematic') {
            ctx.filter += ' sepia(0.25) hue-rotate(180deg) saturate(1.3)';
          } else if (editSettings.colorFilter === 'vibrant') {
            ctx.filter += ' saturate(1.8) contrast(1.15)';
          } else if (editSettings.colorFilter === 'vintage') {
            ctx.filter += ' sepia(0.55) contrast(0.9) brightness(1.05)';
          } else if (editSettings.colorFilter === 'bw') {
            ctx.filter += ' grayscale(1.0) contrast(1.3)';
          } else if (editSettings.colorFilter === 'cyberpunk') {
            ctx.filter += ' hue-rotate(90deg) saturate(2.0)';
          } else if (editSettings.colorFilter === 'warm') {
            ctx.filter += ' sepia(0.3) saturate(1.4)';
          }

          // Draw Video frame maintaining aspect ratio
          const vw = videoEl.videoWidth || 1920;
          const vh = videoEl.videoHeight || 1080;
          const scale = Math.max(canvas.width / vw, canvas.height / vh);
          const dw = vw * scale;
          const dh = vh * scale;
          const dx = (canvas.width - dw) / 2;
          const dy = (canvas.height - dh) / 2;

          try {
            ctx.drawImage(videoEl, dx, dy, dw, dh);
          } catch {
            // ignore cross-origin error on single frame
          }

          // Reset filter for text & overlays
          ctx.filter = 'none';

          // Overlay Title Text
          if (editSettings.overlayText) {
            ctx.save();
            ctx.font = `bold ${Math.max(28, editSettings.textSize * 1.5)}px 'Plus Jakarta Sans', sans-serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';

            const textY = editSettings.textPosition === 'top'
              ? canvas.height * 0.12
              : editSettings.textPosition === 'bottom'
              ? canvas.height * 0.85
              : canvas.height * 0.5;

            const textMetrics = ctx.measureText(editSettings.overlayText);
            const padX = 24;
            const padY = 16;
            ctx.fillStyle = editSettings.textBgColor || 'rgba(0,0,0,0.7)';
            ctx.beginPath();
            ctx.roundRect(
              canvas.width / 2 - textMetrics.width / 2 - padX,
              textY - padY - 14,
              textMetrics.width + padX * 2,
              padY * 2 + 28,
              12
            );
            ctx.fill();

            ctx.fillStyle = editSettings.textColor || '#ffffff';
            ctx.fillText(editSettings.overlayText, canvas.width / 2, textY);
            ctx.restore();
          }

          // Subtitles Overlay
          if (editSettings.enableSubtitles && editSettings.subtitlesScript) {
            ctx.save();
            ctx.font = `600 24px 'Plus Jakarta Sans', sans-serif`;
            ctx.textAlign = 'center';
            ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
            const subText = editSettings.subtitlesScript.slice(0, 80);
            const subMetrics = ctx.measureText(subText);
            const subY = canvas.height - 80;

            ctx.beginPath();
            ctx.roundRect(
              canvas.width / 2 - subMetrics.width / 2 - 18,
              subY - 24,
              subMetrics.width + 36,
              44,
              8
            );
            ctx.fill();

            ctx.fillStyle = '#fde047'; // Yellow text
            ctx.fillText(subText, canvas.width / 2, subY);
            ctx.restore();
          }

          // =========================================================================
          // FIX 3: TÊN THƯƠNG HIỆU (WATERMARK) CHỐNG ĂN CẮP NỘI DUNG
          // Tỉ lệ theo canvas thật (quy chiếu từ khung xem trước rộng 1280px) để
          // cỡ chữ 20px / 13px luôn đúng tương quan dù xuất 1080x1920, 1080x1080
          // hay 1920x1080.
          // =========================================================================
          const brandScale = canvas.width / 1280;

          // Brand Name 1: cố định góc trái trên, cỡ chữ 20px, luôn rõ nét
          if (editSettings.enableBrandName1 && editSettings.brandName1) {
            ctx.save();
            const fontSize1 = Math.max(12, 20 * brandScale);
            ctx.font = `bold ${fontSize1}px 'Plus Jakarta Sans', sans-serif`;
            ctx.textAlign = 'left';
            ctx.textBaseline = 'top';
            ctx.globalAlpha = 1;
            ctx.shadowColor = 'rgba(0,0,0,0.85)';
            ctx.shadowBlur = 6;
            ctx.fillStyle = '#ffffff';
            ctx.fillText(editSettings.brandName1, 18 * brandScale, 16 * brandScale);
            ctx.restore();
          }

          // Brand Name 2: chạy khắp video (marquee liên tục), cỡ chữ 13px, độ mờ 15%
          if (editSettings.enableBrandName2 && editSettings.brandName2) {
            ctx.save();
            const fontSize2 = Math.max(9, 13 * brandScale);
            ctx.font = `bold ${fontSize2}px 'Plus Jakarta Sans', sans-serif`;
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            ctx.globalAlpha = 0.15;
            ctx.fillStyle = '#ffffff';

            const textW = ctx.measureText(editSettings.brandName2).width;
            const speedPxPerSec = 140 * brandScale; // tốc độ chạy ngang
            const elapsedForMarquee = Math.max(0, videoEl.currentTime - trimStart);
            const loopWidth = canvas.width + textW;
            const rawX = canvas.width - ((elapsedForMarquee * speedPxPerSec) % loopWidth);
            const brandY = canvas.height * 0.46;

            ctx.fillText(editSettings.brandName2, rawX, brandY);
            ctx.restore();
          }
        };

        // 5. Start Rendering & Recording Process
        onProgress(15, 'Bắt đầu quá trình mã hóa video và hòa âm Stereo 48kHz...');
        videoEl.currentTime = trimStart;
        videoEl.muted = false;
        videoEl.volume = audioSettings.enableOriginalAudio ? Math.min(1.0, audioSettings.originalVideoVolume) : 0;

        let renderAnimationId: number;
        let isComplete = false;

        const cleanup = () => {
          isComplete = true;
          cancelAnimationFrame(renderAnimationId);
          if (stopBgmFn) stopBgmFn();
          if (stopVoiceFn) stopVoiceFn();
          try {
            carrierOsc.stop();
            carrierOsc.disconnect();
          } catch {}
          try {
            videoEl.pause();
          } catch {}
          try {
            audioCtx.close();
          } catch {}
        };

        recorder.onstop = () => {
          cleanup();
          const finalBlob = new Blob(recordedChunks, {
            type: supportedMime || 'video/mp4'
          });
          const exportedUrl = URL.createObjectURL(finalBlob);
          const sizeMb = (finalBlob.size / (1024 * 1024)).toFixed(2) + ' MB';
          
          const audioReport = [
            audioSettings.enableOriginalAudio ? `Video gốc: ${Math.round(audioSettings.originalVideoVolume * 100)}%` : 'Gốc: Tắt',
            audioSettings.bgmTrackId !== 'none' ? `BGM: ${audioSettings.bgmTitle}` : 'BGM: Tắt',
            audioSettings.enableVoiceover ? 'Voiceover: Bật' : 'Voiceover: Tắt',
            'Stereo 48000Hz (192kbps)'
          ].join(' • ');

          onProgress(100, 'Xuất video hoàn tất thành công!');
          resolve({
            url: exportedUrl,
            blob: finalBlob,
            duration: renderDuration,
            size: sizeMb,
            audioDetails: audioReport
          });
        };

        recorder.onerror = (recErr) => {
          cleanup();
          reject(recErr);
        };

        // Start Recording
        recorder.start(100); // 100ms chunks

        // Play video
        await videoEl.play().catch((err) => {
          console.warn('Lưu ý phát video:', err);
        });

        // Animation Loop
        const tick = () => {
          if (isComplete) return;

          drawFrame();

          const currentElapsed = videoEl.currentTime - trimStart;
          const progressPercent = Math.min(
            98,
            Math.max(15, Math.floor(15 + (currentElapsed / renderDuration) * 82))
          );
          const remaining = Math.max(0, renderDuration - currentElapsed);
          onProgress(
            progressPercent,
            `Đang kết xuất (thời gian thực): ${formatClock(currentElapsed)} / ${formatClock(renderDuration)} — còn khoảng ${formatClock(remaining)} (${progressPercent}%)`
          );

          // Kiểm tra xem đã render đủ thời lượng mong muốn chưa
          if (videoEl.currentTime >= trimEnd || videoEl.currentTime >= rawVideoDuration || videoEl.ended) {
            onProgress(99, 'Đang hoàn tất đóng gói file MP4/WebM...');
            recorder.stop();
            return;
          }

          renderAnimationId = requestAnimationFrame(tick);
        };

        renderAnimationId = requestAnimationFrame(tick);
      } catch (err) {
        console.error('Lỗi khi render video:', err);
        reject(err);
      }
    });
  }
}
