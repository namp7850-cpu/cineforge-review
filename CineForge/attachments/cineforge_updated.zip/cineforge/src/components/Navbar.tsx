import React from 'react';
import { StepId } from '../types';
import { Video, Sparkles, Sliders, PlayCircle, Terminal, Globe, Volume2, CheckCircle2 } from 'lucide-react';
import { ApiStatusBoard } from './ApiStatusBoard';

interface NavbarProps {
  currentStep: StepId;
  onSelectStep: (step: StepId) => void;
  hasInputVideo: boolean;
  hasExportedVideo: boolean;
  onOpenDomainModal: () => void;
  onOpenAiModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentStep,
  onSelectStep,
  hasInputVideo,
  hasExportedVideo,
  onOpenDomainModal,
  onOpenAiModal
}) => {
  const steps: { id: StepId; label: string; number: string; icon: React.ReactNode }[] = [
    { id: 'IMPORT', label: '1. Nhập Video', number: '1', icon: <Video className="w-4 h-4" /> },
    { id: 'DECISION', label: '2. Kịch Bản & Âm Thanh', number: '2', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'EDIT', label: '3. Biên Tập & Xử Lý', number: '3', icon: <Sliders className="w-4 h-4" /> },
    { id: 'EXPORT', label: '4. Xuất Video (Có Tiếng)', number: '4', icon: <PlayCircle className="w-4 h-4" /> },
    { id: 'PYTHON_PIPELINE', label: '5. Python FFmpeg Pipeline', number: '5', icon: <Terminal className="w-4 h-4" /> }
  ];

  return (
    <header className="bg-slate-900/90 backdrop-blur-md border-b border-slate-800 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/20 ring-1 ring-white/20">
              <Video className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-200 to-indigo-300 bg-clip-text text-transparent">
                  CineForge
                </span>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full flex items-center gap-1">
                  <Volume2 className="w-3 h-3 text-emerald-400" /> Audio Master
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium">Studio Biên Tập & Xuất Video Âm Thanh</p>
            </div>
          </div>

          {/* Steps Navigation (Manual Click Only, No Auto-advance) */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-950/60 p-1 rounded-xl border border-slate-800/80">
            {steps.map((s) => {
              const isActive = currentStep === s.id;
              const isDone = (s.id === 'IMPORT' && hasInputVideo) || (s.id === 'EXPORT' && hasExportedVideo);
              return (
                <button
                  key={s.id}
                  id={`nav-step-${s.id}`}
                  onClick={() => onSelectStep(s.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 ring-1 ring-indigo-400/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-bold ${
                    isActive ? 'bg-white text-indigo-700' : isDone ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {isDone && !isActive ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : s.number}
                  </span>
                  <span>{s.label.split('.')[1]}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action: Live API Status, AI Studio & Domain Guide */}
          <div className="flex items-center gap-2">
            <ApiStatusBoard />
            <button
              id="btn-open-ai-hub"
              onClick={onOpenAiModal}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-90 text-white shadow-md shadow-indigo-600/30 transition-all cursor-pointer"
              title="Mở trung tâm AI Studio (Gemini, Groq, DeepSeek, OpenAI...)"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Studio</span>
            </button>
            <button
              id="btn-domain-config"
              onClick={onOpenDomainModal}
              className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-emerald-500/30 hover:border-emerald-500/60 transition-all shadow-sm cursor-pointer"
              title="Hướng dẫn gắn domain thkangctv.com"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">thkangctv.com</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Step Bar */}
      <div className="md:hidden flex items-center justify-between overflow-x-auto px-4 py-2 bg-slate-950 border-t border-slate-800/50 gap-2">
        {steps.map((s) => (
          <button
            key={s.id}
            onClick={() => onSelectStep(s.id)}
            className={`flex-1 min-w-[70px] py-1.5 px-2 rounded-md text-[11px] font-bold text-center transition-all ${
              currentStep === s.id ? 'bg-indigo-600 text-white' : 'bg-slate-900 text-slate-400'
            }`}
          >
            B1-5: {s.number}
          </button>
        ))}
      </div>
    </header>
  );
};
