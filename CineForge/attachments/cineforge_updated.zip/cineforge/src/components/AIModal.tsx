import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Bot,
  Zap,
  Globe,
  Mic,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  RefreshCw,
  X,
  Share2
} from 'lucide-react';
import { AudioSettings, VideoEditSettings, VideoItem } from '../types';

interface AIModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedVideo: VideoItem | null;
  audioSettings: AudioSettings;
  editSettings: VideoEditSettings;
  onApplyScript: (script: string, subtitles: string, title?: string) => void;
}

export const AIModal: React.FC<AIModalProps> = ({
  isOpen,
  onClose,
  selectedVideo,
  audioSettings,
  editSettings,
  onApplyScript
}) => {
  const [activeTab, setActiveTab] = useState<'script' | 'research' | 'transcribe' | 'automation' | 'status'>('script');

  // AI Providers Status
  const [providerStatus, setProviderStatus] = useState<Record<string, boolean>>({});
  const [isLoadingStatus, setIsLoadingStatus] = useState(false);

  // Script Generator State
  const [selectedProvider, setSelectedProvider] = useState<'gemini' | 'groq' | 'deepseek' | 'openai' | 'openrouter'>('gemini');
  const [topic, setTopic] = useState('');
  const [tone, setTone] = useState('cuốn hút, sinh động, viral');
  const [customPrompt, setCustomPrompt] = useState('');
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [generatedResult, setGeneratedResult] = useState<{
    catchyTitle?: string;
    hook?: string;
    script?: string;
    subtitles?: string;
    hashtags?: string[];
  } | null>(null);

  // Tavily Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchingTavily, setIsSearchingTavily] = useState(false);
  const [tavilyResults, setTavilyResults] = useState<{ answer?: string; results?: Array<{ title: string; url: string; content: string }> } | null>(null);

  // AssemblyAI Transcribe State
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [transcribeResult, setTranscribeResult] = useState<string | null>(null);

  // n8n / Discord Automation State
  const [isTriggeringWebhook, setIsTriggeringWebhook] = useState(false);
  const [webhookMessage, setWebhookMessage] = useState<string | null>(null);
  const [isSendingDiscord, setIsSendingDiscord] = useState(false);
  const [discordChannelId, setDiscordChannelId] = useState('1234567890');
  const [discordStatus, setDiscordStatus] = useState<string | null>(null);

  const [copied, setCopied] = useState(false);

  // Fetch status on mount or tab change
  const fetchStatus = async () => {
    setIsLoadingStatus(true);
    try {
      const res = await fetch('/api/ai/status');
      const data = await res.json();
      if (data.success && data.providers) {
        setProviderStatus(data.providers);
      }
    } catch {
      // ignore
    } finally {
      setIsLoadingStatus(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchStatus();
      if (selectedVideo?.title && !topic) {
        setTopic(selectedVideo.title);
      }
    }
  }, [isOpen, selectedVideo]);

  if (!isOpen) return null;

  // Handle Script Generation
  const handleGenerateScript = async () => {
    setIsGeneratingScript(true);
    try {
      const targetDuration = editSettings.trimEnd > editSettings.trimStart
        ? editSettings.trimEnd - editSettings.trimStart
        : selectedVideo?.duration || 30;

      const res = await fetch('/api/ai/generate-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topic || selectedVideo?.title || 'Video sáng tạo',
          videoTitle: selectedVideo?.title || '',
          targetDuration,
          tone,
          provider: selectedProvider,
          customPrompt
        })
      });
      const json = await res.json();
      if (json.success && json.data) {
        setGeneratedResult(json.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingScript(false);
    }
  };

  // Handle Apply Script to Project
  const handleApplyToProject = () => {
    if (!generatedResult) return;
    onApplyScript(
      generatedResult.script || '',
      generatedResult.subtitles || generatedResult.script || '',
      generatedResult.catchyTitle
    );
    onClose();
  };

  // Handle Tavily Research
  const handleTavilySearch = async () => {
    if (!searchQuery.trim()) return;
    setIsSearchingTavily(true);
    try {
      const res = await fetch('/api/ai/tavily-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchQuery })
      });
      const data = await res.json();
      if (data.success) {
        setTavilyResults(data.data);
      } else {
        setTavilyResults({ answer: `Lỗi: ${data.error}` });
      }
    } catch {
      setTavilyResults({ answer: 'Không thể kết nối đến Tavily Search API.' });
    } finally {
      setIsSearchingTavily(false);
    }
  };

  // Handle n8n Webhook Dispatch
  const handleTriggerN8n = async () => {
    setIsTriggeringWebhook(true);
    setWebhookMessage(null);
    try {
      const payload = {
        videoTitle: selectedVideo?.title || 'CineForge Video Project',
        duration: selectedVideo?.duration || 30,
        aspectRatio: editSettings.aspectRatio,
        audioTracks: {
          bgm: audioSettings.bgmTitle,
          voiceover: audioSettings.enableVoiceover,
          voiceoverText: audioSettings.voiceoverText
        }
      };
      const res = await fetch('/api/ai/trigger-n8n', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        setWebhookMessage('Đã kích hoạt workflow n8n thành công!');
      } else {
        setWebhookMessage(`Lỗi webhook: ${data.error || 'Không thành công'}`);
      }
    } catch {
      setWebhookMessage('Không thể gửi webhook đến n8n.');
    } finally {
      setIsTriggeringWebhook(false);
    }
  };

  // Copy helper
  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-md">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span>Trung Tâm Trí Tuệ Nhân Tạo (AI Studio Hub)</span>
                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Full API
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Tích hợp Gemini, Groq, DeepSeek, OpenAI, Tavily Search, AssemblyAI, Discord & n8n
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 py-2.5 bg-slate-950 border-b border-slate-800/80 overflow-x-auto scrollbar-none">
          {[
            { id: 'script', label: 'Tạo Kịch Bản & Lời Thoại', icon: Bot },
            { id: 'research', label: 'Tavily Nghiên Cứu Trend', icon: Globe },
            { id: 'transcribe', label: 'AssemblyAI Phiên Âm', icon: Mic },
            { id: 'automation', label: 'n8n & Discord Webhook', icon: Share2 },
            { id: 'status', label: 'Trạng Thái API', icon: Zap }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Body */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6">
          {/* TAB 1: SCRIPT GENERATOR */}
          {activeTab === 'script' && (
            <div className="space-y-6">
              {/* Provider Selection */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-slate-200">
                  <span className="flex items-center gap-1.5">
                    <Bot className="w-4 h-4 text-indigo-400" />
                    Chọn Mô Hình AI Xử Lý
                  </span>
                  <span className="text-[11px] text-emerald-400 font-mono">
                    Đã cấu hình API Key trong hệ thống
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                  {[
                    { id: 'gemini', name: 'Gemini 2.5 Flash', desc: 'Google DeepMind (Nhanh & Chuẩn)' },
                    { id: 'groq', name: 'Groq LLaMA 3.3', desc: 'Tốc độ siêu cao (500 tokens/s)' },
                    { id: 'deepseek', name: 'DeepSeek V3', desc: 'Tư duy logic & văn phong mượt' },
                    { id: 'openai', name: 'OpenAI GPT-4o', desc: 'Mô hình chuẩn cao cấp' },
                    { id: 'openrouter', name: 'OpenRouter', desc: 'Đa mô hình linh hoạt' }
                  ].map((p) => (
                    <button
                      key={p.id}
                      onClick={() => setSelectedProvider(p.id as typeof selectedProvider)}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        selectedProvider === p.id
                          ? 'bg-indigo-950/60 border-indigo-500 ring-1 ring-indigo-500/40 text-white'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="text-xs font-bold truncate">{p.name}</div>
                      <div className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">{p.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Input Form */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">Chủ Đề hoặc Tiêu Đề video</label>
                  <input
                    type="text"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="Ví dụ: Du lịch Phú Quốc ngắm hoàng hôn..."
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">Phong cách & Giọng điệu</label>
                  <input
                    type="text"
                    value={tone}
                    onChange={(e) => setTone(e.target.value)}
                    placeholder="cuốn hút, hài hước, review nhanh..."
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300">Yêu cầu đặc biệt cho AI (Tùy chọn)</label>
                <input
                  type="text"
                  value={customPrompt}
                  onChange={(e) => setCustomPrompt(e.target.value)}
                  placeholder="Ví dụ: Chèn lời kêu gọi like share ở cuối, dùng từ ngữ giới trẻ..."
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Generate Trigger */}
              <button
                onClick={handleGenerateScript}
                disabled={isGeneratingScript}
                className="w-full py-3 bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 hover:opacity-95 text-white font-bold rounded-xl text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4" />
                <span>{isGeneratingScript ? 'AI Đang Xử Lý & Soạn Thảo Kịch Bản...' : `Tạo Kịch Bản Bằng ${selectedProvider.toUpperCase()}`}</span>
              </button>

              {/* Result Preview */}
              {generatedResult && (
                <div className="bg-slate-950 p-5 rounded-2xl border border-indigo-500/40 space-y-4 shadow-xl">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      Kịch bản AI đã tạo thành công
                    </span>
                    <button
                      onClick={() => handleCopy(generatedResult.script || '')}
                      className="flex items-center gap-1 text-[11px] font-bold text-slate-400 hover:text-white px-2.5 py-1 rounded bg-slate-900 border border-slate-800"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'Đã sao chép' : 'Sao chép'}</span>
                    </button>
                  </div>

                  {generatedResult.catchyTitle && (
                    <div className="space-y-1">
                      <span className="text-[11px] font-bold text-indigo-400 uppercase">Tiêu đề gợi ý:</span>
                      <div className="text-sm font-bold text-white">{generatedResult.catchyTitle}</div>
                    </div>
                  )}

                  {generatedResult.hook && (
                    <div className="p-2.5 rounded-lg bg-indigo-950/40 border border-indigo-500/20 text-xs text-indigo-200">
                      <span className="font-bold text-indigo-300">Hook 3 giây đầu: </span>
                      {generatedResult.hook}
                    </div>
                  )}

                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-slate-400 uppercase">Lời thoại thuyết minh:</span>
                    <p className="text-xs text-slate-200 leading-relaxed bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
                      {generatedResult.script}
                    </p>
                  </div>

                  {generatedResult.hashtags && (
                    <div className="flex flex-wrap gap-1.5">
                      {generatedResult.hashtags.map((tag, i) => (
                        <span key={i} className="text-[10px] font-semibold text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-500/20">
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Apply Button */}
                  <div className="pt-2">
                    <button
                      onClick={handleApplyToProject}
                      className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-emerald-600/30 transition-all"
                    >
                      <Check className="w-4 h-4" />
                      <span>Áp Dụng Kịch Bản Vào Video & Phụ Đề Ngay</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: TAVILY WEB RESEARCH */}
          {activeTab === 'research' && (
            <div className="space-y-5">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                  <Globe className="w-4 h-4 text-emerald-400" />
                  <span>Tavily AI Search - Tìm Kiếm & Nghiên Cứu Nội Dung Xu Hướng Thời Gian Thực</span>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Nhập từ khóa tìm kiếm xu hướng (ví dụ: xu hướng ẩm thực tiktok việt nam 2026)..."
                    className="flex-1 px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                  <button
                    onClick={handleTavilySearch}
                    disabled={isSearchingTavily || !searchQuery.trim()}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
                  >
                    {isSearchingTavily ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Globe className="w-3.5 h-3.5" />}
                    <span>{isSearchingTavily ? 'Đang tìm...' : 'Tìm Kiếm'}</span>
                  </button>
                </div>
              </div>

              {tavilyResults && (
                <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-4">
                  {tavilyResults.answer && (
                    <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/20 text-xs text-emerald-200 leading-relaxed">
                      <div className="font-bold text-emerald-300 mb-1 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5" />
                        Tóm tắt AI:
                      </div>
                      {tavilyResults.answer}
                    </div>
                  )}

                  {tavilyResults.results && tavilyResults.results.length > 0 && (
                    <div className="space-y-3">
                      <div className="text-xs font-bold text-slate-300">Các nguồn thông tin liên quan:</div>
                      {tavilyResults.results.map((r, idx) => (
                        <div key={idx} className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 space-y-1">
                          <div className="text-xs font-bold text-white">{r.title}</div>
                          <p className="text-[11px] text-slate-400 line-clamp-2">{r.content}</p>
                          <a href={r.url} target="_blank" rel="noopener noreferrer" className="text-[10px] text-indigo-400 hover:underline block truncate">
                            {r.url}
                          </a>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: ASSEMBLYAI TRANSCRIBE */}
          {activeTab === 'transcribe' && (
            <div className="space-y-5">
              <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                  <Mic className="w-4 h-4 text-purple-400" />
                  <span>AssemblyAI - Chuyển Giọng Nói Trong Video Thành Phụ Đề Tự Động</span>
                </div>
                <p className="text-xs text-slate-400">
                  Hệ thống sử dụng API AssemblyAI để nhận diện giọng nói và trích xuất phụ đề chính xác.
                </p>
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-xs text-slate-300">
                  <span className="font-bold text-slate-200">Video nguồn: </span>
                  {selectedVideo?.title || 'Chưa chọn video'} ({selectedVideo?.duration || 0} giây)
                </div>
                <button
                  onClick={async () => {
                    setIsTranscribing(true);
                    try {
                      const res = await fetch('/api/ai/transcribe', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ audioUrl: selectedVideo?.url || 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4' })
                      });
                      const data = await res.json();
                      if (data.success) {
                        setTranscribeResult(data.text || 'Phiên âm hoàn tất.');
                      } else {
                        setTranscribeResult(`Lỗi: ${data.error}`);
                      }
                    } catch {
                      setTranscribeResult('Không thể kết nối dịch vụ AssemblyAI.');
                    } finally {
                      setIsTranscribing(false);
                    }
                  }}
                  disabled={isTranscribing}
                  className="w-full py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold cursor-pointer disabled:opacity-50 flex items-center justify-center gap-1.5"
                >
                  <Mic className="w-4 h-4" />
                  <span>{isTranscribing ? 'Đang phiên âm âm thanh...' : 'Bắt Đầu Trích Xuất Phụ Đề'}</span>
                </button>
              </div>

              {transcribeResult && (
                <div className="bg-slate-950 p-4 rounded-xl border border-purple-500/30 text-xs text-slate-200 space-y-2">
                  <div className="font-bold text-purple-400">Kết quả phiên âm:</div>
                  <p className="p-3 bg-slate-900 rounded-lg border border-slate-800 leading-relaxed">{transcribeResult}</p>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: AUTOMATION WEBHOOK & DISCORD */}
          {activeTab === 'automation' && (
            <div className="space-y-6">
              {/* n8n Webhook */}
              <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                    <Share2 className="w-4 h-4 text-emerald-400" />
                    <span>Kích Hoạt Tự Động Hóa Workflow n8n</span>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    Webhook Sẵn Sàng
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Gửi dữ liệu metadata video biên tập sang workflow n8n để tự động render trên cloud hoặc đăng lên mạng xã hội.
                </p>
                <button
                  onClick={handleTriggerN8n}
                  disabled={isTriggeringWebhook}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 disabled:opacity-50"
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>{isTriggeringWebhook ? 'Đang gửi...' : 'Gửi Tín Hiệu Sang n8n Ngay'}</span>
                </button>
                {webhookMessage && (
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200">
                    {webhookMessage}
                  </div>
                )}
              </div>

              {/* Discord Bot Notification */}
              <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-4">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                  <Bot className="w-4 h-4 text-indigo-400" />
                  <span>Gửi Thông Báo Discord Bot</span>
                </div>
                <div className="space-y-2">
                  <label className="text-xs text-slate-300 font-bold">Discord Channel ID</label>
                  <input
                    type="text"
                    value={discordChannelId}
                    onChange={(e) => setDiscordChannelId(e.target.value)}
                    placeholder="Nhập Channel ID Discord..."
                    className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                  />
                </div>
                <button
                  onClick={async () => {
                    setIsSendingDiscord(true);
                    try {
                      const res = await fetch('/api/ai/discord-notify', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                          channelId: discordChannelId,
                          message: `🎬 **CineForge Studio Update**: Video "${selectedVideo?.title}" (${selectedVideo?.duration}s) đã hoàn thành biên tập!`
                        })
                      });
                      const data = await res.json();
                      if (data.success) {
                        setDiscordStatus('Đã gửi thông báo Discord thành công!');
                      } else {
                        setDiscordStatus(`Lỗi Discord: ${data.error || 'Thất bại'}`);
                      }
                    } catch {
                      setDiscordStatus('Không thể kết nối Discord API.');
                    } finally {
                      setIsSendingDiscord(false);
                    }
                  }}
                  disabled={isSendingDiscord}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold cursor-pointer disabled:opacity-50"
                >
                  {isSendingDiscord ? 'Đang gửi...' : 'Gửi Tin Nhắn Discord'}
                </button>
                {discordStatus && (
                  <div className="text-xs text-indigo-300 bg-slate-900 p-3 rounded-xl border border-slate-800">
                    {discordStatus}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 5: STATUS */}
          {activeTab === 'status' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300">Tình trạng các API kết nối trong hệ thống:</span>
                <button
                  onClick={fetchStatus}
                  disabled={isLoadingStatus}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoadingStatus ? 'animate-spin' : ''}`} />
                  <span>Làm mới</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  { key: 'gemini', name: 'Google Gemini 2.5 Flash', desc: 'Mô hình AI đa năng chính' },
                  { key: 'groq', name: 'Groq High-Speed API', desc: 'Xử lý văn bản siêu tốc' },
                  { key: 'deepseek', name: 'DeepSeek API', desc: 'DeepSeek-V3 & DeepSeek-R1' },
                  { key: 'openai', name: 'OpenAI API', desc: 'GPT-4o & Whisper TTS' },
                  { key: 'openrouter', name: 'OpenRouter API', desc: 'Cổng định tuyến đa mô hình' },
                  { key: 'tavily', name: 'Tavily Search API', desc: 'Tìm kiếm nghiên cứu xu hướng' },
                  { key: 'assemblyai', name: 'AssemblyAI API', desc: 'Phiên âm âm thanh thành văn bản' },
                  { key: 'discord', name: 'Discord Bot API', desc: 'Gửi thông báo & tương tác bot' },
                  { key: 'n8n', name: 'n8n Automation Webhook', desc: 'Quy trình tự động hóa workflow' }
                ].map((item) => {
                  const isConfigured = !!providerStatus[item.key];
                  return (
                    <div
                      key={item.key}
                      className={`p-3.5 rounded-xl border flex items-center justify-between ${
                        isConfigured
                          ? 'bg-slate-950 border-emerald-500/30'
                          : 'bg-slate-950/60 border-slate-800 opacity-60'
                      }`}
                    >
                      <div>
                        <div className="text-xs font-bold text-white">{item.name}</div>
                        <div className="text-[11px] text-slate-400 mt-0.5">{item.desc}</div>
                      </div>
                      <div className="flex items-center gap-1 text-[11px] font-bold">
                        {isConfigured ? (
                          <span className="text-emerald-400 flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Hoạt động
                          </span>
                        ) : (
                          <span className="text-amber-400 flex items-center gap-1">
                            <AlertCircle className="w-3.5 h-3.5" /> Chưa có key
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
