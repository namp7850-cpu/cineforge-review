import React, { useState, useEffect, useRef } from 'react';
import { AudioSettings, VideoEditSettings, VideoItem } from '../types';
import { audioEngine } from '../lib/audioEngine';
import { formatDuration } from '../lib/format';
import { Play, Pause, Volume2, ArrowRight, Sparkles } from 'lucide-react';

interface Step3EditProps {
  selectedVideo: VideoItem | null;
  audioSettings: AudioSettings;
  editSettings: VideoEditSettings;
  onChangeEdit: (settings: VideoEditSettings) => void;
  onGoToExport: () => void;
  onGoBack: () => void;
  videoRef: React.RefObject<HTMLVideoElement | null>;
}

export const Step3Edit: React.FC<Step3EditProps> = ({
  selectedVideo,
  audioSettings,
  editSettings,
  onChangeEdit,
  onGoToExport,
  onGoBack,
  videoRef
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [videoDuration, setVideoDuration] = useState(0);
  const [isTestingAudioMix, setIsTestingAudioMix] = useState(false);
  // Theo dõi video nào đã được tự động gán trimEnd = 100% thời lượng thực,
  // để KHÔNG ghi đè lại nếu người dùng chủ động chỉnh trimEnd (kể cả khi họ
  // cố ý chọn đúng 15s) — đây là nguyên nhân gây lỗi "mặc định 15s" trước đây.
  const autoTrimmedForUrl = useRef<string | null>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleLoaded = () => {
      if (video.duration && !isNaN(video.duration) && video.duration > 0) {
        const fullDur = video.duration; // giữ nguyên số thập phân, tính theo thời gian thực chính xác
        setVideoDuration(fullDur);
        const currentUrl = selectedVideo?.url || video.src;
        const needsInitialTrim = editSettings.trimEnd === 0 || editSettings.trimEnd > fullDur + 0.5;
        if (needsInitialTrim && autoTrimmedForUrl.current !== currentUrl) {
          autoTrimmedForUrl.current = currentUrl;
          onChangeEdit({ ...editSettings, trimEnd: fullDur });
        }
      }
    };

    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime);
      if (editSettings.trimEnd > 0 && video.currentTime >= editSettings.trimEnd) {
        video.pause();
        setIsPlaying(false);
      }
    };

    video.addEventListener('loadedmetadata', handleLoaded);
    video.addEventListener('timeupdate', handleTimeUpdate);

    return () => {
      video.removeEventListener('loadedmetadata', handleLoaded);
      video.removeEventListener('timeupdate', handleTimeUpdate);
    };
  }, [videoRef, editSettings, onChangeEdit]);

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
      setIsPlaying(false);
    } else {
      if (video.currentTime < editSettings.trimStart || (editSettings.trimEnd > 0 && video.currentTime >= editSettings.trimEnd)) {
        video.currentTime = editSettings.trimStart;
      }
      video.volume = audioSettings.enableOriginalAudio ? Math.min(1.0, audioSettings.originalVideoVolume) : 0;
      video.play().then(() => setIsPlaying(true)).catch(() => {});
    }
  };

  const handleTestMixedAudio = () => {
    if (isTestingAudioMix) {
      audioEngine.stopTestMixedAudio(videoRef.current);
      setIsTestingAudioMix(false);
    } else {
      setIsTestingAudioMix(true);
      audioEngine.testMixedAudio(audioSettings, videoRef.current, () => {
        setIsTestingAudioMix(false);
      });
    }
  };

  // Color Filter CSS generator
  const getFilterStyle = () => {
    let base = `brightness(${editSettings.brightness}) contrast(${editSettings.contrast}) saturate(${editSettings.saturation})`;
    if (editSettings.colorFilter === 'cinematic') base += ' sepia(0.25) hue-rotate(180deg) saturate(1.3)';
    if (editSettings.colorFilter === 'vibrant') base += ' saturate(1.8) contrast(1.15)';
    if (editSettings.colorFilter === 'vintage') base += ' sepia(0.55) contrast(0.9) brightness(1.05)';
    if (editSettings.colorFilter === 'bw') base += ' grayscale(1.0) contrast(1.3)';
    if (editSettings.colorFilter === 'cyberpunk') base += ' hue-rotate(90deg) saturate(2.0)';
    if (editSettings.colorFilter === 'warm') base += ' sepia(0.3) saturate(1.4)';
    return base;
  };

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-lg">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              BƯỚC 3 / 4
            </span>
            <span className="text-xs text-slate-400 font-semibold">BIÊN TẬP & CĂN CHỈNH CHI TIẾT</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Biên Tập Video, Hiệu Ứng & Màu Sắc
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onGoBack}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition-all cursor-pointer"
          >
            ← Quay Lại
          </button>
          <button
            id="btn-next-to-step4"
            onClick={onGoToExport}
            className="flex items-center gap-1.5 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-600/30 cursor-pointer"
          >
            <span>Sang Bước 4 (Xuất Video)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Video Stage Preview (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl p-4 space-y-4">
            {/* Video Stage Frame */}
            <div className={`relative mx-auto bg-black rounded-xl overflow-hidden flex items-center justify-center ${
              editSettings.aspectRatio === '9:16'
                ? 'aspect-[9/16] max-h-[500px]'
                : editSettings.aspectRatio === '1:1'
                ? 'aspect-square max-h-[440px]'
                : 'aspect-video w-full'
            }`}>
              <video
                ref={videoRef}
                src={selectedVideo?.url || 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'}
                crossOrigin="anonymous"
                playsInline
                className="w-full h-full object-cover transition-all"
                style={{ filter: getFilterStyle() }}
              />

              {/* Text Overlay on Video */}
              {editSettings.overlayText && (
                <div className={`absolute left-0 right-0 px-6 text-center pointer-events-none ${
                  editSettings.textPosition === 'top' ? 'top-6' : editSettings.textPosition === 'bottom' ? 'bottom-16' : 'top-1/2 -translate-y-1/2'
                }`}>
                  <span
                    className="inline-block px-4 py-2 rounded-lg font-bold shadow-lg"
                    style={{
                      backgroundColor: editSettings.textBgColor,
                      color: editSettings.textColor,
                      fontSize: `${Math.max(14, editSettings.textSize * 0.75)}px`
                    }}
                  >
                    {editSettings.overlayText}
                  </span>
                </div>
              )}

              {/* Brand Name 1 - cố định góc trái trên, cỡ chữ 20px */}
              {editSettings.enableBrandName1 && editSettings.brandName1 && (
                <div
                  className="absolute top-3 left-3 pointer-events-none font-bold text-white drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)]"
                  style={{ fontSize: '20px' }}
                >
                  {editSettings.brandName1}
                </div>
              )}

              {/* Brand Name 2 - chạy khắp video, cỡ chữ 13px, độ mờ 15% */}
              {editSettings.enableBrandName2 && editSettings.brandName2 && (
                <div className="absolute inset-0 overflow-hidden pointer-events-none">
                  <div
                    className="absolute whitespace-nowrap font-bold text-white"
                    style={{
                      fontSize: '13px',
                      opacity: 0.15,
                      top: '46%',
                      animation: 'cf-brand-marquee 9s linear infinite'
                    }}
                  >
                    {editSettings.brandName2}
                  </div>
                </div>
              )}

              {/* Subtitles Overlay */}
              {editSettings.enableSubtitles && editSettings.subtitlesScript && (
                <div className="absolute bottom-6 left-4 right-4 text-center pointer-events-none">
                  <span className="inline-block px-3.5 py-1.5 rounded-md bg-slate-950/85 text-yellow-300 text-xs font-bold shadow-lg border border-yellow-500/20">
                    {editSettings.subtitlesScript.slice(0, 75)}
                  </span>
                </div>
              )}
            </div>

            {/* Video Player Controls Bar */}
            <div className="flex items-center justify-between gap-4 bg-slate-900/90 p-3 rounded-xl border border-slate-800">
              <div className="flex items-center gap-3">
                <button
                  id="btn-play-pause"
                  onClick={togglePlay}
                  className="p-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold transition-all shadow-sm cursor-pointer"
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </button>
                <div className="text-xs font-mono font-bold text-slate-300">
                  {formatDuration(currentTime)} / {formatDuration(videoDuration)}
                </div>
              </div>

              {/* Real Audio Testing Trigger */}
              <button
                id="btn-test-mixed-audio"
                onClick={handleTestMixedAudio}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  isTestingAudioMix
                    ? 'bg-rose-600 text-white animate-pulse'
                    : 'bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/40'
                }`}
                title="Nghe thử âm thanh video + BGM + giọng lồng tiếng"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>{isTestingAudioMix ? 'Đang Thử Âm Thanh (Dừng)' : 'Kiểm Tra Âm Thanh Tổng Hợp'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Editing Controls (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Timeline Trimming */}
          <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between text-sm font-bold text-white">
              <span>1. Cắt Ghép Thời Gian (Trim)</span>
              <span className="text-xs font-mono text-indigo-400">
                Thời lượng: {formatDuration(editSettings.trimEnd - editSettings.trimStart)}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5 bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div className="flex justify-between text-[11px] font-bold text-slate-300">
                  <span>Bắt đầu</span>
                  <span className="font-mono text-indigo-400">{editSettings.trimStart}s</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max={Math.max(0, videoDuration - 1)}
                  step="1"
                  value={editSettings.trimStart}
                  onChange={(e) => onChangeEdit({ ...editSettings, trimStart: parseInt(e.target.value) })}
                  className="w-full accent-indigo-500"
                />
              </div>

              <div className="space-y-1.5 bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div className="flex justify-between text-[11px] font-bold text-slate-300">
                  <span>Kết thúc</span>
                  <span className="font-mono text-indigo-400">{editSettings.trimEnd || Math.floor(videoDuration)}s</span>
                </div>
                <input
                  type="range"
                  min={editSettings.trimStart + 1}
                  max={Math.max(editSettings.trimStart + 1, Math.floor(videoDuration))}
                  step="1"
                  value={editSettings.trimEnd || Math.floor(videoDuration)}
                  onChange={(e) => onChangeEdit({ ...editSettings, trimEnd: parseInt(e.target.value) })}
                  className="w-full accent-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Color Filters */}
          <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 space-y-4">
            <div className="text-sm font-bold text-white">2. Bộ Lọc Màu Điện Ảnh</div>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'normal', label: 'Gốc' },
                { id: 'cinematic', label: 'Điện ảnh' },
                { id: 'vibrant', label: 'Rực rỡ' },
                { id: 'vintage', label: 'Vintage' },
                { id: 'bw', label: 'Trắng đen' },
                { id: 'cyberpunk', label: 'Cyberpunk' }
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => onChangeEdit({ ...editSettings, colorFilter: f.id as 'normal' | 'cinematic' | 'vibrant' | 'vintage' | 'bw' | 'cyberpunk' })}
                  className={`py-2 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    editSettings.colorFilter === f.id
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'bg-slate-950 text-slate-400 hover:bg-slate-800 border border-slate-800'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* Visual Sliders */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                <span>Độ sáng: {Math.round(editSettings.brightness * 100)}%</span>
                <input
                  type="range"
                  min="0.5"
                  max="1.5"
                  step="0.05"
                  value={editSettings.brightness}
                  onChange={(e) => onChangeEdit({ ...editSettings, brightness: parseFloat(e.target.value) })}
                  className="w-36 accent-indigo-500"
                />
              </div>
              <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                <span>Độ tương phản: {Math.round(editSettings.contrast * 100)}%</span>
                <input
                  type="range"
                  min="0.5"
                  max="1.5"
                  step="0.05"
                  value={editSettings.contrast}
                  onChange={(e) => onChangeEdit({ ...editSettings, contrast: parseFloat(e.target.value) })}
                  className="w-36 accent-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Text Overlay & Aspect Ratio */}
          <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 space-y-4">
            <div className="text-sm font-bold text-white">3. Tiêu Đề & Tỉ Lệ Khung Hình</div>
            {/* Aspect Ratio Selector */}
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: '16:9', label: '16:9 Ngang' },
                { id: '9:16', label: '9:16 Shorts' },
                { id: '1:1', label: '1:1 Vuông' }
              ].map((ratio) => (
                <button
                  key={ratio.id}
                  onClick={() => onChangeEdit({ ...editSettings, aspectRatio: ratio.id as '16:9' | '9:16' | '1:1' })}
                  className={`py-2 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    editSettings.aspectRatio === ratio.id
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-950 text-slate-400 hover:bg-slate-800 border border-slate-800'
                  }`}
                >
                  {ratio.label}
                </button>
              ))}
            </div>

            {/* Overlay Text Input */}
            <input
              type="text"
              value={editSettings.overlayText}
              onChange={(e) => onChangeEdit({ ...editSettings, overlayText: e.target.value })}
              placeholder="Nhập chữ chèn trên video (nếu có)..."
              className="w-full px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Brand Name Watermarks */}
          <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center gap-2 text-sm font-bold text-white">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>4. Tên Thương Hiệu (Watermark)</span>
            </div>

            {/* Brand 1 */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-slate-300">
                  Tên thương hiệu 1 — góc trái trên, cỡ chữ 20px, cố định
                </label>
                <button
                  onClick={() => onChangeEdit({ ...editSettings, enableBrandName1: !editSettings.enableBrandName1 })}
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full border cursor-pointer ${
                    editSettings.enableBrandName1
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : 'bg-slate-800 text-slate-500 border-slate-700'
                  }`}
                >
                  {editSettings.enableBrandName1 ? 'Đang bật' : 'Đang tắt'}
                </button>
              </div>
              <input
                type="text"
                value={editSettings.brandName1}
                onChange={(e) => onChangeEdit({ ...editSettings, brandName1: e.target.value })}
                placeholder="Nhập tên thương hiệu 1 (VD: CineForge Studio)..."
                className="w-full px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Brand 2 */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-slate-300">
                  Tên thương hiệu 2 — chạy khắp video, cỡ chữ 13px, mờ 15%
                </label>
                <button
                  onClick={() => onChangeEdit({ ...editSettings, enableBrandName2: !editSettings.enableBrandName2 })}
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full border cursor-pointer ${
                    editSettings.enableBrandName2
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : 'bg-slate-800 text-slate-500 border-slate-700'
                  }`}
                >
                  {editSettings.enableBrandName2 ? 'Đang bật' : 'Đang tắt'}
                </button>
              </div>
              <input
                type="text"
                value={editSettings.brandName2}
                onChange={(e) => onChangeEdit({ ...editSettings, brandName2: e.target.value })}
                placeholder="Nhập tên thương hiệu 2 (VD: thkangctv.com)..."
                className="w-full px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {(!editSettings.brandName1 || !editSettings.brandName2) && (
              <div className="text-[11px] text-amber-300 bg-amber-950/30 border border-amber-500/30 rounded-lg p-2.5">
                Bạn chưa nhập đủ tên thương hiệu. Vui lòng nhập tên cho{' '}
                {!editSettings.brandName1 && !editSettings.brandName2
                  ? 'cả hai ô trên'
                  : !editSettings.brandName1
                  ? 'Tên thương hiệu 1'
                  : 'Tên thương hiệu 2'}{' '}
                trước khi xuất video — nếu để trống, watermark tương ứng sẽ không hiển thị.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
