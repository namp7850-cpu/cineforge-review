import React, { useEffect, useRef, useState } from 'react';
import { CheckCircle2, XCircle, RefreshCw, ChevronDown, Radio } from 'lucide-react';

interface ProviderDetail {
  configured: boolean;
  preview: string | null;
  envVar: string;
}

interface StatusResponse {
  success: boolean;
  providers: Record<string, boolean>;
  details?: Record<string, ProviderDetail>;
  checkedAt?: string;
}

const PROVIDER_LIST = [
  { key: 'gemini', name: 'Google Gemini 2.5 Flash' },
  { key: 'groq', name: 'Groq High-Speed API' },
  { key: 'deepseek', name: 'DeepSeek API' },
  { key: 'openai', name: 'OpenAI API' },
  { key: 'openrouter', name: 'OpenRouter API' },
  { key: 'tavily', name: 'Tavily Search API' },
  { key: 'assemblyai', name: 'AssemblyAI API' },
  { key: 'discord', name: 'Discord Bot API' },
  { key: 'n8n', name: 'n8n Automation Webhook' }
];

// Bảng trạng thái API hiện NGAY và tự làm mới liên tục (real-time) để bạn biết
// chính xác API nào đang chạy (xanh = ON) và API nào chưa (xám/đỏ = OFF).
// Nếu bạn vừa dán API key vào .env nhưng ở đây vẫn báo OFF: server cần được
// KHỞI ĐỘNG LẠI (restart) để đọc giá trị .env mới — biến môi trường chỉ được
// nạp một lần lúc server khởi động.
export const ApiStatusBoard: React.FC = () => {
  const [data, setData] = useState<StatusResponse | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [lastError, setLastError] = useState<string | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchStatus = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/ai/status', { cache: 'no-store' });
      const json = await res.json();
      if (json.success) {
        setData(json);
        setLastError(null);
      } else {
        setLastError('Không đọc được trạng thái API.');
      }
    } catch {
      setLastError('Không thể kết nối máy chủ để kiểm tra API.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    // Tự động làm mới mỗi 8 giây => luôn hiện đúng trạng thái thời gian thực
    timerRef.current = setInterval(fetchStatus, 8000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const providers = data?.providers || {};
  const details = data?.details || {};
  const onCount = PROVIDER_LIST.filter((p) => providers[p.key]).length;
  const totalCount = PROVIDER_LIST.length;
  const allOff = onCount === 0;

  return (
    <div className="relative">
      <button
        id="btn-api-status-board"
        onClick={() => setIsOpen((v) => !v)}
        className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
          allOff
            ? 'bg-slate-800 border-rose-500/30 text-rose-300'
            : 'bg-slate-800 border-emerald-500/30 text-emerald-300'
        }`}
        title="Trạng thái các API AI đang chạy (thời gian thực)"
      >
        <span className="relative flex h-2 w-2">
          <span
            className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
              allOff ? 'bg-rose-400' : 'bg-emerald-400'
            }`}
          />
          <span
            className={`relative inline-flex rounded-full h-2 w-2 ${allOff ? 'bg-rose-500' : 'bg-emerald-500'}`}
          />
        </span>
        <Radio className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">API: {onCount}/{totalCount} Đang Chạy</span>
        <span className="sm:hidden">{onCount}/{totalCount}</span>
        <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-[340px] max-h-[70vh] overflow-y-auto bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl z-50 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-200">Bảng Trạng Thái API AI (Real-time)</span>
            <button
              onClick={fetchStatus}
              disabled={isLoading}
              className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-900 border border-slate-800 text-[11px] font-bold text-slate-300 hover:text-white cursor-pointer"
            >
              <RefreshCw className={`w-3 h-3 ${isLoading ? 'animate-spin' : ''}`} />
              <span>Làm mới</span>
            </button>
          </div>

          {lastError && (
            <div className="text-[11px] text-rose-300 bg-rose-950/30 border border-rose-500/30 rounded-lg p-2">
              {lastError}
            </div>
          )}

          <div className="space-y-1.5">
            {PROVIDER_LIST.map((p) => {
              const isOn = !!providers[p.key];
              const detail = details[p.key];
              return (
                <div
                  key={p.key}
                  className={`flex items-center justify-between gap-2 p-2.5 rounded-xl border ${
                    isOn ? 'bg-emerald-500/5 border-emerald-500/30' : 'bg-slate-900/60 border-slate-800'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="text-[11px] font-bold text-white truncate">{p.name}</div>
                    <div className="text-[10px] text-slate-500 font-mono truncate">
                      {detail?.envVar}
                      {detail?.preview ? ` • ${detail.preview}` : ''}
                    </div>
                  </div>
                  {isOn ? (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 flex-shrink-0">
                      <CheckCircle2 className="w-3.5 h-3.5" /> ON
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-slate-500 flex-shrink-0">
                      <XCircle className="w-3.5 h-3.5" /> OFF
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          <div className="text-[10px] text-slate-500 leading-relaxed border-t border-slate-800 pt-2.5">
            Đã có key trong .env nhưng vẫn báo <span className="text-rose-400 font-bold">OFF</span>? Biến môi
            trường chỉ được đọc một lần lúc server khởi động — hãy <span className="text-emerald-400 font-bold">khởi
            động lại server</span> rồi bấm "Làm mới". Bảng này tự làm mới mỗi 8 giây.
          </div>
        </div>
      )}
    </div>
  );
};
