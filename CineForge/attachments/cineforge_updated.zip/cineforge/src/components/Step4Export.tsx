import React, { useState } from 'react';
import { AudioSettings, RenderResult, VideoEditSettings, VideoItem } from '../types';
import { VideoExporter } from '../lib/videoExporter';
import { SAMPLE_VIDEOS } from '../lib/sampleVideos';
import { formatDuration } from '../lib/format';
import { Download, CheckCircle2, Volume2, Sparkles, Terminal, Copy, Check, FileVideo, ArrowLeft, RefreshCw, AlertCircle, Globe2, Clock } from 'lucide-react';

interface Step4ExportProps {
  selectedVideo: VideoItem | null;
  audioSettings: AudioSettings;
  editSettings: VideoEditSettings;
  renderResult: RenderResult;
  onUpdateRenderResult: (result: RenderResult) => void;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  onGoToPythonPipeline: () => void;
  onGoBackToEdit: () => void;
}

export const Step4Export: React.FC<Step4ExportProps> = ({
  selectedVideo,
  audioSettings,
  editSettings,
  renderResult,
  onUpdateRenderResult,
  videoRef,
  onGoToPythonPipeline,
  onGoBackToEdit
}) => {
  const [copiedFfmpeg, setCopiedFfmpeg] = useState(false);

  // Trigger Video Rendering with Full Mixed Audio (Works 100% on browser immediately)
  const handleStartRender = async () => {
    const activeVideo = selectedVideo || SAMPLE_VIDEOS[0];
    onUpdateRenderResult({
      ...renderResult,
      isRendering: true,
      progress: 5,
      statusMessage: 'Đang khởi chạy kết xuất video & hòa âm trên trình duyệt...',
      error: null
    });

    try {
      const result = await VideoExporter.renderVideoWithAudio(
        activeVideo,
        audioSettings,
        editSettings,
        (prog, msg) => {
          onUpdateRenderResult({
            ...renderResult,
            isRendering: true,
            progress: prog,
            statusMessage: msg
          });
        },
        videoRef.current
      );

      onUpdateRenderResult({
        isRendering: false,
        progress: 100,
        statusMessage: 'Xuất video hoàn tất thành công!',
        exportedUrl: result.url,
        exportedBlob: result.blob,
        exportedFilename: `CineForge_${activeVideo.title.slice(0, 20).replace(/\s+/g, '_')}_MasterAudio.mp4`,
        exportedDuration: result.duration,
        exportedSize: result.size,
        hasAudio: true,
        audioDetails: result.audioDetails,
        error: null
      });
    } catch (err: unknown) {
      console.error('Render error:', err);
      onUpdateRenderResult({
        ...renderResult,
        isRendering: false,
        error: (err as Error)?.message || 'Có lỗi xảy ra trong quá trình xuất video trên trình duyệt.'
      });
    }
  };

  // Download Exported Video
  const handleDownload = () => {
    if (!renderResult.exportedUrl) return;
    const a = document.createElement('a');
    a.href = renderResult.exportedUrl;
    a.download = renderResult.exportedFilename || 'CineForge_Exported_Video.mp4';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const ffmpegCmd = VideoExporter.generateFfmpegCommand(
    'video_goc.mp4',
    'video_xuat_co_tieng.mp4',
    audioSettings,
    editSettings
  );

  const copyFfmpeg = () => {
    navigator.clipboard.writeText(ffmpegCmd);
    setCopiedFfmpeg(true);
    setTimeout(() => setCopiedFfmpeg(false), 2000);
  };

  const activeVideo = selectedVideo || SAMPLE_VIDEOS[0];
  const calculatedDuration = editSettings.trimEnd > editSettings.trimStart
    ? (editSettings.trimEnd - editSettings.trimStart)
    : activeVideo.duration;

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-lg">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              BƯỚC 4 / 4
            </span>
            <span className="text-xs text-slate-400 font-semibold">XUẤT VIDEO TRỰC TIẾP TRÊN WEB & TẢI VỀ</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Xuất Video Hoàn Chỉnh (Có Tiếng 100% & Chuẩn Độ Dài)
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onGoBackToEdit}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Quay Lại Bước 3</span>
          </button>
          <button
            onClick={onGoToPythonPipeline}
            className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 rounded-xl text-xs font-bold transition-all cursor-pointer"
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Mở Python FFmpeg Cho Máy Local</span>
          </button>
        </div>
      </div>

      {/* Answer & Direct Capability Notice */}
      <div className="p-4 bg-emerald-950/30 border border-emerald-500/30 rounded-2xl flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center flex-shrink-0">
            <Globe2 className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-emerald-300 flex items-center gap-2">
              <span>Xuất video hoạt động trực tiếp 100% ngay trên trình duyệt Web này</span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-[10px] text-emerald-300 border border-emerald-500/40 font-mono">
                Độ dài: {renderResult.exportedDuration > 0 ? formatDuration(renderResult.exportedDuration) : formatDuration(calculatedDuration)}
              </span>
            </div>
            <div className="text-[11px] text-slate-400">
              Bạn không cần bật VS Code hay Python terminal vẫn xuất và tải video MP4 đầy đủ âm thanh ngay tại đây.
            </div>
          </div>
        </div>

        {!renderResult.isRendering && !renderResult.exportedUrl && (
          <button
            id="btn-quick-render"
            onClick={handleStartRender}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-extrabold shadow-md shadow-emerald-600/30 transition-all cursor-pointer whitespace-nowrap"
          >
            XUẤT VIDEO NGAY
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Exported Video Player or Render Trigger (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {renderResult.exportedUrl ? (
            /* Persistent Exported Video Player */
            <div className="bg-slate-900/90 p-6 rounded-2xl border border-emerald-500/30 shadow-2xl space-y-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-bold text-emerald-400">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Video Thành Phẩm Đã Sẵn Sàng (Có Âm Thanh)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold bg-slate-950 px-2.5 py-1 rounded text-emerald-400 border border-slate-800 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{renderResult.exportedDuration.toFixed(1)}s</span>
                  </span>
                  <span className="text-xs font-mono font-bold bg-slate-950 px-2.5 py-1 rounded text-slate-300 border border-slate-800">
                    {renderResult.exportedSize}
                  </span>
                </div>
              </div>

              {/* Player */}
              <div className="relative aspect-video w-full bg-black rounded-xl overflow-hidden shadow-lg border border-slate-800">
                <video
                  src={renderResult.exportedUrl}
                  controls
                  autoPlay
                  playsInline
                  className="w-full h-full object-contain"
                />
              </div>

              {/* Audio Verification Badge */}
              <div className="bg-slate-950 p-4 rounded-xl border border-emerald-500/20 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                  <Volume2 className="w-4 h-4" />
                  <span>Xác Nhận Luồng Âm Thanh Xuất Ra:</span>
                </div>
                <p className="text-xs text-slate-300 font-medium">
                  {renderResult.audioDetails || 'Stereo 192kbps AAC/Opus - Trộn âm video gốc + nhạc nền + thuyết minh.'}
                </p>
              </div>

              {/* Action Download Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  id="btn-download-video"
                  onClick={handleDownload}
                  className="flex-1 py-3.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-600/30 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>TẢI VIDEO MP4 VỀ MÁY</span>
                </button>
                <button
                  onClick={handleStartRender}
                  disabled={renderResult.isRendering}
                  className="py-3.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Xuất Lại Video</span>
                </button>
              </div>
            </div>
          ) : (
            /* Render Trigger Box */
            <div className="bg-slate-900/90 p-8 rounded-2xl border border-slate-800 text-center space-y-6 shadow-xl">
              <div className="w-16 h-16 rounded-2xl bg-indigo-600/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mx-auto shadow-inner">
                <FileVideo className="w-8 h-8" />
              </div>

              <div className="max-w-md mx-auto space-y-2">
                <h2 className="text-lg font-bold text-white">Sẵn Sàng Xuất Video Ngay Trên Web</h2>
                <p className="text-xs text-slate-400">
                  Hệ thống kết xuất trực tiếp bằng Web Audio Engine + Canvas Engine, tổng hợp hình ảnh, bộ lọc màu, nhạc nền và giọng đọc AI thành một video có âm thanh chuẩn Stereo.
                </p>
              </div>

              {/* Exact Duration Information Badge — tính đúng theo thời gian thực của video (không còn mặc định 15s) */}
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs font-semibold text-slate-300">
                <Clock className="w-4 h-4 text-indigo-400" />
                <span>Thời lượng xuất video gốc:</span>
                <span className="text-emerald-400 font-mono font-bold">{formatDuration(calculatedDuration)} (100% Trọn Vẹn)</span>
              </div>

              {/* Rendering Progress Indicator */}
              {renderResult.isRendering ? (
                <div className="space-y-4 max-w-md mx-auto bg-slate-950 p-5 rounded-xl border border-slate-800">
                  <div className="flex justify-between text-xs font-bold text-slate-200">
                    <span className="text-left">{renderResult.statusMessage}</span>
                    <span className="font-mono text-emerald-400">{renderResult.progress}%</span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-indigo-500 via-teal-400 to-emerald-400 transition-all duration-200"
                      style={{ width: `${renderResult.progress}%` }}
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <button
                    id="btn-start-render"
                    onClick={handleStartRender}
                    className="px-8 py-4 bg-gradient-to-r from-indigo-600 via-emerald-600 to-teal-500 hover:from-indigo-500 hover:to-emerald-400 text-white rounded-xl text-sm font-extrabold shadow-xl shadow-emerald-600/25 transition-all cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
                  >
                    BẮT ĐẦU XUẤT VIDEO (CÓ ÂM THANH 100%)
                  </button>
                  {/* FIX: bỏ ước lượng cố định sai "~3-8 giây" — cơ chế ghi hình phát
                      video thật (real-time capture) nên thời gian xuất LUÔN đúng bằng
                      độ dài video cần xuất, tính động theo phút/giây thực tế. */}
                  <p className="text-[11px] text-slate-500">
                    Thời gian xuất dự kiến: <span className="text-slate-300 font-semibold">≈ {formatDuration(calculatedDuration)}</span> (xuất theo thời gian thực, đúng bằng độ dài video)
                  </p>
                  {calculatedDuration > 180 && (
                    <p className="text-[11px] text-amber-400 max-w-md mx-auto">
                      Video khá dài ({formatDuration(calculatedDuration)}) nên xuất trên trình duyệt sẽ mất tương ứng thời gian đó và có thể bị đứng máy nếu chuyển tab. Với video dài, nên dùng "Python FFmpeg Cho Máy Local" ở góc trên để xuất nhanh hơn, không theo thời gian thực.
                    </p>
                  )}
                </div>
              )}

              {renderResult.error && (
                <div className="p-3.5 bg-rose-950/40 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-center gap-2 text-left">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
                  <span>{renderResult.error}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Column: Audio & FFmpeg Details (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Audio Preserved Guarantee Box */}
          <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center gap-2 text-sm font-bold text-white">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Các Kênh Âm Thanh Sẽ Được Xuất Ra:</span>
            </div>

            <div className="space-y-2.5 text-xs text-slate-300">
              <div className="flex justify-between items-center p-2.5 bg-slate-950 rounded-xl border border-slate-800/80">
                <span className="text-slate-400">Âm thanh video gốc:</span>
                <span className="font-semibold text-slate-200">
                  {audioSettings.enableOriginalAudio ? `${Math.round(audioSettings.originalVideoVolume * 100)}%` : 'Tắt'}
                </span>
              </div>
              <div className="flex justify-between items-center p-2.5 bg-slate-950 rounded-xl border border-slate-800/80">
                <span className="text-slate-400">Nhạc nền (BGM):</span>
                <span className="font-semibold text-indigo-300">
                  {audioSettings.bgmTrackId !== 'none' ? `${audioSettings.bgmTitle} (${Math.round(audioSettings.bgmVolume * 100)}%)` : 'Không dùng'}
                </span>
              </div>
              <div className="flex justify-between items-center p-2.5 bg-slate-950 rounded-xl border border-slate-800/80">
                <span className="text-slate-400">Giọng đọc thuyết minh:</span>
                <span className="font-semibold text-emerald-400">
                  {audioSettings.enableVoiceover ? `Bật (${Math.round(audioSettings.voiceoverVolume * 100)}%)` : 'Tắt'}
                </span>
              </div>
              <div className="flex justify-between items-center p-2.5 bg-slate-950 rounded-xl border border-slate-800/80">
                <span className="text-slate-400">Chuẩn âm thanh:</span>
                <span className="font-mono text-teal-300">Stereo 48000Hz (192kbps)</span>
              </div>
              <div className="flex justify-between items-center p-2.5 bg-slate-950 rounded-xl border border-slate-800/80">
                <span className="text-slate-400">Bảo toàn độ dài:</span>
                <span className="font-mono text-amber-300">{formatDuration(calculatedDuration)} (100% gốc)</span>
              </div>
              <div className="flex justify-between items-center p-2.5 bg-slate-950 rounded-xl border border-slate-800/80">
                <span className="text-slate-400">Thương hiệu 1 (góc trái):</span>
                <span className={`font-semibold ${editSettings.enableBrandName1 && editSettings.brandName1 ? 'text-emerald-400' : 'text-slate-500'}`}>
                  {editSettings.enableBrandName1 && editSettings.brandName1 ? editSettings.brandName1 : 'Chưa nhập'}
                </span>
              </div>
              <div className="flex justify-between items-center p-2.5 bg-slate-950 rounded-xl border border-slate-800/80">
                <span className="text-slate-400">Thương hiệu 2 (chạy khắp video):</span>
                <span className={`font-semibold ${editSettings.enableBrandName2 && editSettings.brandName2 ? 'text-emerald-400' : 'text-slate-500'}`}>
                  {editSettings.enableBrandName2 && editSettings.brandName2 ? editSettings.brandName2 : 'Chưa nhập'}
                </span>
              </div>
            </div>
          </div>

          {/* Local FFmpeg Alternative Command Box */}
          <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-bold text-slate-200">
                <Terminal className="w-4 h-4 text-indigo-400" />
                <span>Lệnh FFmpeg Chuẩn (Nếu Chạy Local)</span>
              </div>
              <button
                onClick={copyFfmpeg}
                className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition-all cursor-pointer"
              >
                {copiedFfmpeg ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedFfmpeg ? 'Đã chép' : 'Sao chép'}</span>
              </button>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-indigo-300 overflow-x-auto break-all leading-relaxed max-h-32">
              {ffmpegCmd}
            </div>
            <div className="text-[11px] text-slate-400 flex items-center justify-between">
              <span>Tích hợp <code className="text-emerald-300">amix</code> và <code className="text-emerald-300">-c:a aac -b:a 192k</code></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
