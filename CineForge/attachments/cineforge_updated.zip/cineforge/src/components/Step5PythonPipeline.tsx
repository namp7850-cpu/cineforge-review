import React, { useState } from 'react';
import { Copy, Check, Download, Terminal, Code2, AlertTriangle, ShieldCheck, FileCode } from 'lucide-react';

export const Step5PythonPipeline: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<'bien_tap_video' | 'pipeline' | 'ops' | 'requirements'>('bien_tap_video');
  const [copied, setCopied] = useState(false);

  const files = {
    bien_tap_video: {
      name: 'bien_tap_video.py',
      language: 'python',
      content: `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CineForge Video & Audio Pipeline - Biên tập video bảo toàn âm thanh 100%
Đã fix triệt để lỗi xuất video không có âm thanh bằng cách:
1. Tự động kiểm tra luồng âm thanh gốc bằng ffprobe.
2. Trộn đa luồng (Audio Video Gốc + Nhạc Nền BGM + Giọng Đọc TTS) qua filter amix.
3. Tạo luồng âm thanh giả lập (anullsrc) nếu video gốc là video câm.
4. Mã hóa âm thanh chuẩn AAC 192k 48000Hz.
"""

import os
import sys
import subprocess
import json

def check_has_audio(input_file):
    """Kiểm tra file video có chứa stream audio hay không"""
    cmd = [
        "ffprobe", "-v", "error",
        "-select_streams", "a",
        "-show_entries", "stream=codec_type",
        "-of", "json", input_file
    ]
    try:
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        data = json.loads(res.stdout)
        return len(data.get("streams", [])) > 0
    except Exception:
        return False

def bien_tap_video(
    input_video="video_goc.mp4",
    output_video="video_xuat_hoan_thanh.mp4",
    bgm_file=None,
    voice_file=None,
    orig_volume=1.0,
    bgm_volume=0.3,
    voice_volume=1.2,
    aspect_ratio="16:9"
):
    print(f"🎬 Đang xử lý video: {input_video} -> {output_video}")
    has_orig_audio = check_has_audio(input_video)
    print(f"🔊 Kiểm tra âm thanh video gốc: {'CÓ âm thanh' if has_orig_audio else 'KHÔNG có âm thanh (Sẽ tạo luồng audio bù)'}")

    # Xây dựng danh sách input và filter_complex
    inputs = ["-i", input_video]
    filter_complex = []
    audio_labels = []
    current_input_idx = 1

    # 1. Xử lý Video (Tỉ lệ khung hình)
    if aspect_ratio == "9:16":
        filter_complex.append("[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920[vout]")
    elif aspect_ratio == "1:1":
        filter_complex.append("[0:v]scale=1080:1080:force_original_aspect_ratio=increase,crop=1080:1080[vout]")
    else:
        filter_complex.append("[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2[vout]")

    # 2. Xử lý âm thanh gốc
    if has_orig_audio and orig_volume > 0:
        filter_complex.append(f"[0:a]volume={orig_volume}[a_orig]")
        audio_labels.append("[a_orig]")

    # 3. Thêm Nhạc Nền (BGM)
    if bgm_file and os.path.exists(bgm_file) and bgm_volume > 0:
        inputs.extend(["-i", bgm_file])
        filter_complex.append(f"[{current_input_idx}:a]volume={bgm_volume},aloop=loop=-1:size=2e+09[a_bgm]")
        audio_labels.append("[a_bgm]")
        current_input_idx += 1

    # 4. Thêm Giọng Đọc Thuyết Minh (TTS Voice)
    if voice_file and os.path.exists(voice_file) and voice_volume > 0:
        inputs.extend(["-i", voice_file])
        filter_complex.append(f"[{current_input_idx}:a]volume={voice_volume}[a_voice]")
        audio_labels.append("[a_voice]")
        current_input_idx += 1

    # 5. Trộn các luồng âm thanh
    if len(audio_labels) > 1:
        inputs_str = "".join(audio_labels)
        filter_complex.append(f"{inputs_str}amix=inputs={len(audio_labels)}:duration=first:dropout_transition=2[aout]")
        map_audio = ["-map", "[aout]"]
    elif len(audio_labels) == 1:
        map_audio = ["-map", audio_labels[0]]
    else:
        # Nếu không có âm thanh nào, tạo luồng im lặng để video chuẩn không bị mất audio header
        filter_complex.append("anullsrc=channel_layout=stereo:sample_rate=48000[aout]")
        map_audio = ["-map", "[aout]"]

    filter_complex_str = "; ".join(filter_complex)

    # Lệnh FFmpeg đầy đủ
    cmd = [
        "ffmpeg", "-y",
        *inputs,
        "-filter_complex", filter_complex_str,
        "-map", "[vout]",
        *map_audio,
        "-c:v", "libx264", "-preset", "fast", "-crf", "20",
        "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
        output_video
    ]

    print("🚀 Thực thi FFmpeg Command:")
    print(" ".join(cmd))
    
    result = subprocess.run(cmd)
    if result.returncode == 0:
        print(f"✅ Xuất video thành công: {output_video} (Đầy đủ âm thanh)")
    else:
        print(f"❌ Lỗi trong quá trình chạy FFmpeg: mã lỗi {result.returncode}")

if __name__ == "__main__":
    bien_tap_video()`
    },
    pipeline: {
      name: 'pipeline.py',
      language: 'python',
      content: `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CineForge Pipeline Orchestrator - Quy trình biên tập tuần tự
"""

from ops import VideoOps, AudioOps
from bien_tap_video import bien_tap_video

def run_full_pipeline():
    print("=== BẮT ĐẦU QUY TRÌNH BIÊN TẬP VIDEO CINEFORGE ===")
    
    # Bước 1: Chuẩn bị input
    input_video = "input.mp4"
    bgm_music = "bgm_lofi.mp3"
    voice_audio = "voiceover.mp3"
    output_video = "final_output.mp4"

    # Bước 2: Biên tập và hòa trộn âm thanh
    bien_tap_video(
        input_video=input_video,
        output_video=output_video,
        bgm_file=bgm_music,
        voice_file=voice_audio,
        orig_volume=0.8,
        bgm_volume=0.25,
        voice_volume=1.2,
        aspect_ratio="16:9"
    )

if __name__ == "__main__":
    run_full_pipeline()`
    },
    ops: {
      name: 'ops.py',
      language: 'python',
      content: `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Các thao tác Video & Audio cốt lõi bằng FFmpeg
"""

import subprocess

class VideoOps:
    @staticmethod
    def trim_video(input_path, output_path, start_sec, end_sec):
        cmd = [
            "ffmpeg", "-y",
            "-ss", str(start_sec),
            "-to", str(end_sec),
            "-i", input_path,
            "-c:v", "copy",
            "-c:a", "copy",
            output_path
        ]
        return subprocess.run(cmd).returncode == 0

class AudioOps:
    @staticmethod
    def mix_audio_tracks(audio1, audio2, output_audio, vol1=1.0, vol2=0.3):
        cmd = [
            "ffmpeg", "-y",
            "-i", audio1,
            "-i", audio2,
            "-filter_complex", f"[0:a]volume={vol1}[a1];[1:a]volume={vol2}[a2];[a1][a2]amix=inputs=2:duration=first[aout]",
            "-map", "[aout]",
            "-c:a", "aac", "-b:a", "192k",
            output_audio
        ]
        return subprocess.run(cmd).returncode == 0`
    },
    requirements: {
      name: 'requirements.txt',
      language: 'text',
      content: `# Yêu cầu thư viện Python cho CineForge Pipeline
ffmpeg-python>=0.2.0
numpy>=1.24.0
requests>=2.31.0
google-genai>=2.4.0`
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(files[selectedFile].content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const file = files[selectedFile];
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-lg">
        <div className="flex items-center gap-2 mb-1">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
            BƯỚC 5 / 5
          </span>
          <span className="text-xs text-slate-400 font-semibold">TÍCH HỢP PYTHON FFMPEG CHO MÁY LOCAL</span>
        </div>
        <h1 className="text-2xl font-bold text-white tracking-tight">
          Mã Nguồn Python Pipeline & Khắc Phục Âm Thanh
        </h1>
      </div>

      {/* Root Cause & Fix Explanation */}
      <div className="bg-slate-900/90 p-6 rounded-2xl border border-indigo-500/30 space-y-4 shadow-xl">
        <div className="flex items-center gap-2 text-sm font-bold text-emerald-400">
          <ShieldCheck className="w-5 h-5" />
          <span>Giải Thích & Sửa Triệt Để Lỗi Xuất Video Không Có Tiếng (FFmpeg Audio)</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-300">
          <div className="p-4 bg-slate-950 rounded-xl border border-rose-500/30 space-y-2">
            <div className="flex items-center gap-2 text-rose-400 font-bold">
              <AlertTriangle className="w-4 h-4" />
              <span>Nguyên nhân code cũ bị mất tiếng:</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-400">
              <li>Lệnh FFmpeg thiếu tham số <code className="text-rose-300">-c:a aac -b:a 192k</code> hoặc vô tình có cờ <code className="text-rose-300">-an</code>.</li>
              <li>Chưa dùng bộ lọc trộn âm <code className="text-rose-300">amix</code> khi kết hợp nhiều nguồn âm thanh (nhạc nền + giọng đọc).</li>
              <li>Video gốc không có sẵn audio stream khiến FFmpeg bỏ qua toàn bộ luồng tiếng.</li>
            </ul>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-emerald-500/30 space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 font-bold">
              <ShieldCheck className="w-4 h-4" />
              <span>Cách CineForge khắc phục 100%:</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-300">
              <li>Tự động dùng <code className="text-emerald-300">ffprobe</code> quét luồng âm thanh đầu vào.</li>
              <li>Dùng <code className="text-emerald-300">amix=inputs=N:duration=first</code> trộn đồng bộ âm video gốc + BGM + TTS.</li>
              <li>Tự động gắn <code className="text-emerald-300">anullsrc</code> tạo luồng âm thanh giả lập nếu video nguồn là video câm.</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Code Viewer */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl space-y-0">
        {/* Tab Headers */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-950 border-b border-slate-800 overflow-x-auto">
          <div className="flex items-center gap-2">
            {(['bien_tap_video', 'pipeline', 'ops', 'requirements'] as const).map((key) => (
              <button
                key={key}
                onClick={() => setSelectedFile(key)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  selectedFile === key
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <FileCode className="w-3.5 h-3.5" />
                <span>{files[key].name}</span>
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold transition-all cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Đã sao chép' : 'Sao chép file'}</span>
            </button>
            <button
              onClick={handleDownloadFile}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Tải {files[selectedFile].name}</span>
            </button>
          </div>
        </div>

        {/* Code Content */}
        <pre className="p-6 bg-slate-950 text-slate-200 text-xs font-mono overflow-x-auto leading-relaxed max-h-[500px]">
          {files[selectedFile].content}
        </pre>
      </div>
    </div>
  );
};
