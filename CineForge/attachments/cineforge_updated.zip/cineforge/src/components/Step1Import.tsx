import React, { useState, useMemo } from 'react';
import { VideoItem } from '../types';
import { SAMPLE_VIDEOS, CATEGORIES } from '../lib/sampleVideos';
import { Search, Link2, Upload, Play, CheckCircle2, ChevronLeft, ChevronRight, Film, ArrowRight, X } from 'lucide-react';

interface Step1ImportProps {
  selectedVideo: VideoItem | null;
  onSelectVideo: (video: VideoItem) => void;
  onGoToNextStep: () => void;
}

export const Step1Import: React.FC<Step1ImportProps> = ({
  selectedVideo,
  onSelectVideo,
  onGoToNextStep
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Tất cả');
  const [aspectRatioFilter, setAspectRatioFilter] = useState<'all' | '16:9' | '9:16'>('all');
  const [urlInput, setUrlInput] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(6);
  const [isUrlLoading, setIsUrlLoading] = useState(false);
  const [previewVideo, setPreviewVideo] = useState<VideoItem | null>(null);

  // Filter videos based on query, category, and aspect ratio
  const filteredVideos = useMemo(() => {
    return SAMPLE_VIDEOS.filter((v) => {
      const matchQuery = searchQuery.trim() === '' || 
        v.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        v.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        v.author.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchCategory = selectedCategory === 'Tất cả' || v.category === selectedCategory;
      const matchRatio = aspectRatioFilter === 'all' || v.aspectRatio === aspectRatioFilter;
      return matchQuery && matchCategory && matchRatio;
    });
  }, [searchQuery, selectedCategory, aspectRatioFilter]);

  // Pagination calculation
  const totalPages = Math.max(1, Math.ceil(filteredVideos.length / itemsPerPage));
  const paginatedVideos = useMemo(() => {
    const startIdx = (currentPage - 1) * itemsPerPage;
    return filteredVideos.slice(startIdx, startIdx + itemsPerPage);
  }, [filteredVideos, currentPage, itemsPerPage]);

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };

  // Handle URL import
  const handleImportUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;
    setIsUrlLoading(true);

    const isShort = urlInput.includes('tiktok') || urlInput.includes('shorts') || urlInput.includes('reel');
    const actualUrl = urlInput.startsWith('http') ? urlInput : 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4';
    
    const tempVideo = document.createElement('video');
    tempVideo.preload = 'metadata';
    tempVideo.src = actualUrl;

    const finalize = (durationSec: number) => {
      const newVideo: VideoItem = {
        id: `url-${Date.now()}`,
        title: `Video Nhập Link: ${urlInput.slice(0, 45)}...`,
        url: actualUrl,
        thumbnail: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=600&auto=format&fit=crop&q=80',
        duration: Math.max(5, Math.round(durationSec)),
        source: 'url',
        category: isShort ? 'Shorts' : 'Công nghệ',
        resolution: '1080p Full HD',
        aspectRatio: isShort ? '9:16' : '16:9',
        author: 'Liên kết trực tiếp',
        views: 'Tùy chỉnh'
      };
      onSelectVideo(newVideo);
      setIsUrlLoading(false);
    };

    tempVideo.onloadedmetadata = () => {
      finalize(tempVideo.duration || 60);
    };
    tempVideo.onerror = () => {
      finalize(45);
    };
  };

  // Handle local video file upload with accurate duration detection
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileUrl = URL.createObjectURL(file);
    const tempVideo = document.createElement('video');
    tempVideo.preload = 'metadata';
    tempVideo.src = fileUrl;

    const finalize = (durationSec: number, width: number, height: number) => {
      const isVertical = height > width;
      const resText = width && height ? `${width}x${height}` : '1080p Full HD';
      const newVideo: VideoItem = {
        id: `file-${Date.now()}`,
        title: file.name.replace(/\.[^/.]+$/, ''),
        url: fileUrl,
        thumbnail: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?w=600&auto=format&fit=crop&q=80',
        duration: Math.max(1, Math.round(durationSec)),
        source: 'upload',
        category: 'File tải lên',
        resolution: resText,
        aspectRatio: isVertical ? '9:16' : '16:9',
        author: 'Từ máy tính của bạn'
      };
      onSelectVideo(newVideo);
    };

    tempVideo.onloadedmetadata = () => {
      finalize(tempVideo.duration || 60, tempVideo.videoWidth, tempVideo.videoHeight);
    };
    tempVideo.onerror = () => {
      finalize(60, 1920, 1080);
    };
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Top Header Card */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-5 bg-gradient-to-r from-slate-900 via-slate-900/90 to-indigo-950/40 p-6 rounded-2xl border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 tracking-wider">
              BƯỚC 1 / 4
            </span>
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
              Nhập Nguồn Video Ban Đầu
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Chọn Video Nguồn Để Biên Tập
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
            Dán link YouTube/TikTok, tải file từ máy tính hoặc chọn video mẫu có sẵn bên dưới.
          </p>
        </div>

        {/* Selected Video Pill & Next Action */}
        {selectedVideo && (
          <div className="relative z-10 flex items-center gap-3.5 bg-slate-950/90 p-3.5 rounded-2xl border border-emerald-500/40 shadow-xl flex-shrink-0">
            <div className="w-14 h-10 rounded-xl bg-slate-800 overflow-hidden relative border border-slate-700 flex-shrink-0">
              <img src={selectedVideo.thumbnail} alt={selectedVideo.title} className="w-full h-full object-cover" />
            </div>
            <div className="max-w-[190px]">
              <div className="text-xs font-bold text-white truncate">{selectedVideo.title}</div>
              <div className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1 mt-0.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Thời lượng: {Math.floor(selectedVideo.duration / 60)}:{(selectedVideo.duration % 60).toString().padStart(2, '0')}</span>
              </div>
            </div>
            <button
              id="btn-next-to-step2"
              onClick={onGoToNextStep}
              className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-indigo-600/30 cursor-pointer flex-shrink-0"
            >
              <span>Sang Bước 2</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Input Options Grid: 1. URL Paste / 2. File Upload */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Direct Link Input */}
        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 space-y-4 hover:border-slate-700 transition-all shadow-md">
          <div className="flex items-center gap-2 font-bold text-slate-200 text-sm">
            <div className="w-7 h-7 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
              <Link2 className="w-4 h-4" />
            </div>
            <span>Nhập Đường Link (YouTube / TikTok / MP4 Trực Tiếp)</span>
          </div>
          <form onSubmit={handleImportUrl} className="flex gap-2">
            <input
              id="input-video-url"
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="Dán link video MP4, YouTube hoặc TikTok vào đây..."
              className="flex-1 px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-mono"
            />
            <button
              type="submit"
              disabled={isUrlLoading || !urlInput.trim()}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all cursor-pointer flex-shrink-0 shadow-md shadow-indigo-600/20"
            >
              {isUrlLoading ? 'Đang nạp...' : 'Lấy Video'}
            </button>
          </form>
        </div>

        {/* File Upload Box */}
        <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 space-y-4 hover:border-slate-700 transition-all shadow-md">
          <div className="flex items-center gap-2 font-bold text-slate-200 text-sm">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Upload className="w-4 h-4" />
            </div>
            <span>Tải Video Từ Máy Tính Cá Nhân (MP4, WebM, MOV)</span>
          </div>
          <label className="flex items-center justify-center gap-3 px-4 py-2.5 bg-slate-950 hover:bg-slate-800/80 border border-dashed border-slate-700 hover:border-emerald-500/50 rounded-xl cursor-pointer transition-all">
            <Upload className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-semibold text-slate-300">Bấm để chọn file video từ thiết bị của bạn</span>
            <input
              type="file"
              accept="video/mp4,video/webm,video/quicktime"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* Video Search & Filtering Section */}
      <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 space-y-6 shadow-xl">
        {/* Search Header & Controls */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
          {/* Search Bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              id="search-video-input"
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Tìm kiếm theo từ khóa (Shorts, Du lịch, Công nghệ, Ẩm thực...)"
              className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Ratio Filter & Items Per Page */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
              <button
                onClick={() => { setAspectRatioFilter('all'); setCurrentPage(1); }}
                className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  aspectRatioFilter === 'all' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Mọi tỉ lệ
              </button>
              <button
                onClick={() => { setAspectRatioFilter('16:9'); setCurrentPage(1); }}
                className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  aspectRatioFilter === '16:9' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                16:9 Ngang
              </button>
              <button
                onClick={() => { setAspectRatioFilter('9:16'); setCurrentPage(1); }}
                className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  aspectRatioFilter === '9:16' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                9:16 Dọc
              </button>
            </div>

            {/* Items Per Page */}
            <div className="flex items-center gap-2 text-xs text-slate-400 font-semibold">
              <span>Hiển thị:</span>
              <select
                value={itemsPerPage}
                onChange={(e) => {
                  setItemsPerPage(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none focus:border-indigo-500 font-semibold cursor-pointer"
              >
                <option value={6}>6 video / trang</option>
                <option value={12}>12 video / trang</option>
                <option value={24}>24 video / trang</option>
              </select>
            </div>
          </div>
        </div>

        {/* Categories Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                setSelectedCategory(cat);
                setCurrentPage(1);
              }}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Video Grid */}
        {paginatedVideos.length === 0 ? (
          <div className="text-center py-12 text-slate-400 bg-slate-950/40 rounded-xl border border-slate-800">
            <Film className="w-8 h-8 mx-auto mb-2 text-slate-500" />
            <p className="text-sm font-semibold">Không tìm thấy video phù hợp</p>
            <p className="text-xs text-slate-500 mt-1">Hãy thử tìm kiếm với từ khóa khác hoặc xóa bộ lọc.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {paginatedVideos.map((vid) => {
              const isSelected = selectedVideo?.id === vid.id;
              return (
                <div
                  key={vid.id}
                  id={`video-card-${vid.id}`}
                  className={`group relative bg-slate-950 rounded-2xl overflow-hidden border transition-all flex flex-col ${
                    isSelected
                      ? 'border-indigo-500 ring-2 ring-indigo-500/40 shadow-xl shadow-indigo-500/10'
                      : 'border-slate-800 hover:border-slate-700 hover:shadow-lg'
                  }`}
                >
                  {/* Thumbnail & Badges */}
                  <div className="relative aspect-video w-full bg-slate-900 overflow-hidden">
                    <img
                      src={vid.thumbnail}
                      alt={vid.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-black/40" />
                    
                    {/* Aspect Ratio Badge */}
                    <span className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded text-[10px] font-extrabold bg-black/80 backdrop-blur-md text-white border border-white/10">
                      {vid.aspectRatio}
                    </span>
                    {/* Duration Badge */}
                    <span className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded text-[10px] font-bold bg-black/80 text-white font-mono">
                      {Math.floor(vid.duration / 60)}:{(vid.duration % 60).toString().padStart(2, '0')}
                    </span>
                    {/* Resolution */}
                    <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded text-[9px] font-bold bg-indigo-600/90 text-white">
                      {vid.resolution}
                    </span>
                    {/* Quick Preview Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setPreviewVideo(vid);
                      }}
                      className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40 cursor-pointer"
                      title="Xem trước video này"
                    >
                      <div className="w-11 h-11 rounded-full bg-white/20 backdrop-blur-md hover:bg-white/30 text-white flex items-center justify-center shadow-lg transition-transform hover:scale-110">
                        <Play className="w-5 h-5 fill-white translate-x-0.5" />
                      </div>
                    </button>
                    {/* Selected Indicator */}
                    {isSelected && (
                      <div className="absolute inset-0 bg-indigo-600/25 flex items-center justify-center pointer-events-none">
                        <div className="w-10 h-10 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg ring-2 ring-white">
                          <CheckCircle2 className="w-6 h-6" />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Info */}
                  <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                    <div>
                      <h3 className="text-xs font-bold text-white line-clamp-2 leading-relaxed">
                        {vid.title}
                      </h3>
                      <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 font-medium">
                        <span>{vid.author}</span>
                        <span>{vid.views || '120K'} lượt xem</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onSelectVideo(vid)}
                        className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                        }`}
                      >
                        {isSelected ? '✓ Đang Được Chọn' : 'Chọn Video Này'}
                      </button>
                      <button
                        onClick={() => setPreviewVideo(vid)}
                        className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 cursor-pointer transition-colors"
                        title="Xem thử video"
                      >
                        <Play className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Pagination Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-800">
          <div className="text-xs text-slate-400 font-medium">
            Hiển thị <span className="text-white font-bold">{Math.min(filteredVideos.length, (currentPage - 1) * itemsPerPage + 1)}</span> đến <span className="text-white font-bold">{Math.min(filteredVideos.length, currentPage * itemsPerPage)}</span> trong tổng số <span className="text-white font-bold">{filteredVideos.length}</span> video
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-prev-page"
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className="p-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            {/* Page numbers */}
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
              <button
                key={pageNum}
                id={`btn-page-${pageNum}`}
                onClick={() => handlePageChange(pageNum)}
                className={`w-8 h-8 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  currentPage === pageNum
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-950 text-slate-400 hover:bg-slate-800 hover:text-white border border-slate-800'
                }`}
              >
                {pageNum}
              </button>
            ))}

            <button
              id="btn-next-page"
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className="p-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-all"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Floating Action Bar when video is selected */}
      {selectedVideo && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-30 flex items-center gap-4 bg-slate-900/95 backdrop-blur-md px-6 py-3.5 rounded-full border border-indigo-500/40 shadow-2xl animate-fade-in max-w-xl w-[90%] justify-between">
          <div className="flex items-center gap-3 truncate">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse flex-shrink-0" />
            <span className="text-xs text-white font-bold truncate">
              {selectedVideo.title}
            </span>
          </div>
          <button
            onClick={onGoToNextStep}
            className="flex items-center gap-2 px-5 py-2 rounded-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-90 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 cursor-pointer flex-shrink-0 transition-all"
          >
            <span>Tiếp tục Bước 2</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Mini Video Preview Modal */}
      {previewVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950">
              <div className="text-xs font-bold text-white truncate max-w-md">
                Xem Thử: {previewVideo.title}
              </div>
              <button
                onClick={() => setPreviewVideo(null)}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="aspect-video bg-black">
              <video
                src={previewVideo.url}
                controls
                autoPlay
                className="w-full h-full object-contain"
              />
            </div>
            <div className="p-4 bg-slate-950 flex items-center justify-between">
              <div className="text-xs text-slate-400">
                {previewVideo.resolution} • {previewVideo.aspectRatio} • {previewVideo.duration}s
              </div>
              <button
                onClick={() => {
                  onSelectVideo(previewVideo);
                  setPreviewVideo(null);
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                Chọn Video Này & Tiếp Tục
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
