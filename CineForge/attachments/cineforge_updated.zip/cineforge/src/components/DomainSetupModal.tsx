import React, { useState } from 'react';
import { X, Globe, Server, ShieldCheck, Copy, Check, Terminal } from 'lucide-react';

interface DomainSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DomainSetupModal: React.FC<DomainSetupModalProps> = ({ isOpen, onClose }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const nginxConfig = `server {
    listen 80;
    server_name thkangctv.com www.thkangctv.com;
    # Chuyển hướng HTTP sang HTTPS bắt buộc
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name thkangctv.com www.thkangctv.com;

    # Chứng chỉ SSL Let's Encrypt
    ssl_certificate /etc/letsencrypt/live/thkangctv.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/thkangctv.com/privkey.pem;

    location / {
        # Trỏ vào Node / Vite (mặc định 3000 hoặc cổng bạn cấu hình)
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # Hỗ trợ upload video dung lượng lớn
        client_max_body_size 500M;
    }
}`;

  const viteConfigCode = `// vite.config.ts
export default defineConfig({
  server: {
    host: '0.0.0.0', // Cho phép truy cập từ bên ngoài / domain
    port: 3000,      // Đổi thành 3000 (hoặc cổng bạn mong muốn)
    allowedHosts: ['thkangctv.com', 'www.thkangctv.com', 'localhost']
  }
});`;

  const certbotCommand = `sudo apt update && sudo apt install -y nginx certbot python3-certbot-nginx
sudo certbot --nginx -d thkangctv.com -d www.thkangctv.com`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Hướng Dẫn Cấu Hình Tên Miền thkangctv.com</h2>
              <p className="text-xs text-slate-400">Kết nối ứng dụng local với website chính thức thkangctv.com</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto text-sm text-slate-300">
          {/* Step 1: DNS Setup */}
          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center gap-2 font-semibold text-emerald-400">
              <Server className="w-4 h-4" />
              <span>Bước 1: Trỏ Bản Ghi DNS Tên Miền (Tại Cloudflare / Nhà Cung Cấp)</span>
            </div>
            <p className="text-xs text-slate-400">
              Truy cập trang quản trị tên miền (ví dụ Cloudflare, Namecheap, iNET, PA Vietnam) và tạo 2 bản ghi:
            </p>
            <div className="grid grid-cols-3 gap-2 text-xs font-mono bg-slate-900 p-3 rounded-lg border border-slate-800 text-slate-200">
              <div><span className="text-slate-500">Loại:</span> A</div>
              <div><span className="text-slate-500">Tên:</span> @ (hoặc thkangctv.com)</div>
              <div><span className="text-slate-500">Giá trị:</span> [Địa chỉ IP VPS của bạn]</div>
              <div><span className="text-slate-500">Loại:</span> CNAME</div>
              <div><span className="text-slate-500">Tên:</span> www</div>
              <div><span className="text-slate-500">Giá trị:</span> thkangctv.com</div>
            </div>
          </div>

          {/* Step 2: Change Port in Vite / Node */}
          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-semibold text-indigo-400">
                <Terminal className="w-4 h-4" />
                <span>Bước 2: Cấu Hình Cổng Chạy (Đổi từ 8080 sang 3000 / Port chuẩn)</span>
              </div>
              <button
                onClick={() => copyToClipboard(viteConfigCode, 'vite')}
                className="flex items-center gap-1 text-xs text-slate-400 hover:text-white bg-slate-800 px-2.5 py-1 rounded cursor-pointer"
              >
                {copiedKey === 'vite' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'vite' ? 'Đã sao chép' : 'Sao chép'}</span>
              </button>
            </div>
            <pre className="p-3 bg-slate-900 text-slate-200 rounded-lg text-xs font-mono overflow-x-auto border border-slate-800">
              {viteConfigCode}
            </pre>
          </div>

          {/* Step 3: Nginx Reverse Proxy Config */}
          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-semibold text-amber-400">
                <ShieldCheck className="w-4 h-4" />
                <span>Bước 3: File Cấu Hình Nginx Reverse Proxy Cho thkangctv.com</span>
              </div>
              <button
                onClick={() => copyToClipboard(nginxConfig, 'nginx')}
                className="flex items-center gap-1 text-xs text-slate-400 hover:text-white bg-slate-800 px-2.5 py-1 rounded cursor-pointer"
              >
                {copiedKey === 'nginx' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'nginx' ? 'Đã sao chép' : 'Sao chép'}</span>
              </button>
            </div>
            <p className="text-xs text-slate-400">
              Lưu vào đường dẫn <code className="text-indigo-300">/etc/nginx/sites-available/thkangctv.com</code> rồi kích hoạt bằng lệnh <code className="text-indigo-300">sudo ln -s /etc/nginx/sites-available/thkangctv.com /etc/nginx/sites-enabled/</code>:
            </p>
            <pre className="p-3 bg-slate-900 text-slate-200 rounded-lg text-xs font-mono overflow-x-auto border border-slate-800 max-h-48">
              {nginxConfig}
            </pre>
          </div>

          {/* Step 4: SSL Certificate */}
          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-semibold text-rose-400">
                <ShieldCheck className="w-4 h-4" />
                <span>Bước 4: Cài Đặt SSL HTTPS Miễn Phí (Let's Encrypt)</span>
              </div>
              <button
                onClick={() => copyToClipboard(certbotCommand, 'ssl')}
                className="flex items-center gap-1 text-xs text-slate-400 hover:text-white bg-slate-800 px-2.5 py-1 rounded cursor-pointer"
              >
                {copiedKey === 'ssl' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'ssl' ? 'Đã sao chép' : 'Sao chép'}</span>
              </button>
            </div>
            <pre className="p-3 bg-slate-900 text-slate-200 rounded-lg text-xs font-mono overflow-x-auto border border-slate-800">
              {certbotCommand}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 bg-slate-950/50">
          <span className="text-xs text-slate-400 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            Website sẽ hoạt động chính thức tại https://thkangctv.com
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white transition-all cursor-pointer shadow-md shadow-indigo-600/20"
          >
            Đóng & Tiếp Tục
          </button>
        </div>
      </div>
    </div>
  );
};
