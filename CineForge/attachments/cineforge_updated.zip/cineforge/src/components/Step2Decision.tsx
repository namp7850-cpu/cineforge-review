import React, { useState } from 'react';
import { AudioSettings, VideoEditSettings, VideoItem } from '../types';
import { BGM_TRACKS, audioEngine } from '../lib/audioEngine';
import { Sparkles, Music, Mic, Wand2, Play, Square, ArrowRight, Sliders, Bell } from 'lucide-react';

interface Step2DecisionProps {
  selectedVideo: VideoItem | null;
  audioSettings: AudioSettings;
  editSettings: VideoEditSettings;
  onChangeAudio: (settings: AudioSettings) => void;
  onChangeEdit: (settings: VideoEditSettings) => void;
  onGoToNextStep: () => void;
  onGoBack: () => void;
  onOpenAiModal?: () => void;
}

export const Step2Decision: React.FC<Step2DecisionProps> = ({
  selectedVideo,
  audioSettings,
  editSettings,
  onChangeAudio,
  onChangeEdit,
  onGoToNextStep,
  onGoBack,
  onOpenAiModal
}) => {
  const [isPlayingBgm, setIsPlayingBgm] = useState<string | null>(null);
  const [isTestingVoice, setIsTestingVoice] = useState(false);
  const [isAiGenerating, setIsAiGenerating] = useState(false);

  // Toggle BGM Playback preview
  const handleToggleBgm = (trackId: string) => {
    if (isPlayingBgm === trackId) {
      audioEngine.stopBGM();
      setIsPlayingBgm(null);
    } else {
      audioEngine.stopBGM();
      if (trackId !== 'none') {
        audioEngine.playSynthesizedBGM(trackId, audioSettings.bgmVolume, true);
        setIsPlayingBgm(trackId);
      } else {
        setIsPlayingBgm(null);
      }
    }
  };

  // Test Speech Synthesis Voice
  const handleTestVoice = () => {
    if (isTestingVoice) {
      audioEngine.stopSpeaking();
      setIsTestingVoice(false);
    } else {
      setIsTestingVoice(true);
      const textToSpeak = audioSettings.voiceoverText || 'Xin chào! Bạn đang thử nghiệm giọng đọc thuyết minh trực tiếp của CineForge.';
      audioEngine.speakText(
        textToSpeak,
        audioSettings.voiceoverLang,
        audioSettings.voiceoverSpeed,
        audioSettings.voiceoverPitch,
        () => setIsTestingVoice(false)
      );
    }
  };

  // Real AI Script generation via server backend API (Gemini/Groq/OpenAI)
  const handleGenerateScript = async () => {
    setIsAiGenerating(true);
    try {
      const topic = selectedVideo?.title || 'video sáng tạo';
      const targetDuration = editSettings.trimEnd > editSettings.trimStart
        ? editSettings.trimEnd - editSettings.trimStart
        : selectedVideo?.duration || 30;

      const res = await fetch('/api/ai/generate-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic,
          videoTitle: selectedVideo?.title || '',
          targetDuration,
          tone: 'cuốn hút, sinh động, tự nhiên'
        })
      });
      const json = await res.json();
      if (json.success && json.data) {
        const scriptText = json.data.script || json.data.hook || `Chào bạn! Cùng khám phá ${topic} trong video hôm nay.`;
        const subText = json.data.subtitles || scriptText;
        
        onChangeAudio({
          ...audioSettings,
          voiceoverText: scriptText,
          enableVoiceover: true
        });
        onChangeEdit({
          ...editSettings,
          subtitlesScript: subText,
          overlayText: json.data.catchyTitle || editSettings.overlayText,
          enableSubtitles: true
        });
      } else {
        throw new Error('Fallback required');
      }
    } catch {
      const topic = selectedVideo?.title || 'video sáng tạo';
      const fallback = `Chào bạn! Trong video ngắn hôm nay, chúng ta cùng khám phá những góc nhìn tuyệt đẹp nhất về ${topic}.`;
      onChangeAudio({
        ...audioSettings,
        voiceoverText: fallback,
        enableVoiceover: true
      });
      onChangeEdit({
        ...editSettings,
        subtitlesScript: fallback,
        enableSubtitles: true
      });
    } finally {
      setIsAiGenerating(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-lg">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              BƯỚC 2 / 4
            </span>
            <span className="text-xs text-slate-400 font-semibold">TRỘM QUYẾT ĐỊNH & THIẾT LẬP ÂM THANH</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Kịch Bản, Giọng Đọc & Trộn Âm Thanh
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onGoBack}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition-all cursor-pointer"
          >
            ← Quay Lại
          </button>
          <button
            id="btn-next-to-step3"
            onClick={onGoToNextStep}
            className="flex items-center gap-1.5 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-indigo-600/30 cursor-pointer"
          >
            <span>Sang Bước 3 (Biên Tập)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Script & Voiceover (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Script Generator Box */}
          <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <Mic className="w-4 h-4 text-indigo-400" />
                <span>1. Giọng Đọc Thuyết Minh AI & Kịch Bản</span>
              </div>
              <div className="flex items-center gap-2">
                {onOpenAiModal && (
                  <button
                    onClick={onOpenAiModal}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-90 text-white text-xs font-bold transition-all cursor-pointer shadow-sm shadow-purple-600/20"
                    title="Mở bảng điều khiển AI Studio"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>AI Studio Hub</span>
                  </button>
                )}
                <button
                  onClick={handleGenerateScript}
                  disabled={isAiGenerating}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-bold transition-all cursor-pointer"
                >
                  <Wand2 className="w-3.5 h-3.5 text-indigo-400" />
                  <span>{isAiGenerating ? 'Đang tạo kịch bản...' : 'AI Tạo Nhanh'}</span>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-4 bg-slate-950 p-3 rounded-xl border border-slate-800">
              <label className="flex items-center gap-2 text-xs font-bold text-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={audioSettings.enableVoiceover}
                  onChange={(e) => onChangeAudio({ ...audioSettings, enableVoiceover: e.target.checked })}
                  className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 bg-slate-900 border-slate-700"
                />
                <span>Kích hoạt giọng đọc thuyết minh vào video</span>
              </label>
              <label className="flex items-center gap-2 text-xs font-bold text-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={audioSettings.autoDucking}
                  onChange={(e) => onChangeAudio({ ...audioSettings, autoDucking: e.target.checked })}
                  className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 bg-slate-900 border-slate-700"
                />
                <span>Tự động giảm nhạc nền khi nói (Audio Ducking)</span>
              </label>
            </div>

            <textarea
              id="textarea-voiceover-text"
              rows={4}
              value={audioSettings.voiceoverText}
              onChange={(e) => {
                const text = e.target.value;
                onChangeAudio({ ...audioSettings, voiceoverText: text });
                onChangeEdit({ ...editSettings, subtitlesScript: text });
              }}
              placeholder="Nhập nội dung lời thoại hoặc kịch bản giọng đọc thuyết minh tại đây..."
              className="w-full p-3.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 leading-relaxed font-sans"
            />

            {/* Voice Controls: Speed, Pitch, Language */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div className="space-y-1.5">
                <div className="flex justify-between text-[11px] text-slate-300 font-semibold">
                  <span>Tốc độ đọc</span>
                  <span className="text-indigo-400 font-mono">{audioSettings.voiceoverSpeed}x</span>
                </div>
                <input
                  type="range"
                  min="0.7"
                  max="1.5"
                  step="0.05"
                  value={audioSettings.voiceoverSpeed}
                  onChange={(e) => onChangeAudio({ ...audioSettings, voiceoverSpeed: parseFloat(e.target.value) })}
                  className="w-full accent-indigo-500"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-[11px] text-slate-300 font-semibold">
                  <span>Cao độ giọng (Pitch)</span>
                  <span className="text-indigo-400 font-mono">{audioSettings.voiceoverPitch}x</span>
                </div>
                <input
                  type="range"
                  min="0.6"
                  max="1.4"
                  step="0.05"
                  value={audioSettings.voiceoverPitch}
                  onChange={(e) => onChangeAudio({ ...audioSettings, voiceoverPitch: parseFloat(e.target.value) })}
                  className="w-full accent-indigo-500"
                />
              </div>

              <div className="flex items-end">
                <button
                  id="btn-test-voice"
                  onClick={handleTestVoice}
                  className={`w-full py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    isTestingVoice
                      ? 'bg-rose-600 text-white'
                      : 'bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/40'
                  }`}
                >
                  {isTestingVoice ? <Square className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{isTestingVoice ? 'Dừng Đọc' : 'Thử Nghe Giọng'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Sound Effects Box */}
          <div className="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center gap-2 text-sm font-bold text-white">
              <Bell className="w-4 h-4 text-amber-400" />
              <span>2. Thư Viện Hiệu Ứng Âm Thanh (SFX)</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
              {[
                { id: 'ding', label: 'Ding Chuông' },
                { id: 'whoosh', label: 'Whoosh Lướt' },
                { id: 'pop', label: 'Pop Nút' },
                { id: 'bass_drop', label: 'Bass Drop' },
                { id: 'applause', label: 'Vỗ Tay' }
              ].map((sfx) => (
                <button
                  key={sfx.id}
                  onClick={() => audioEngine.playSFX(sfx.id as 'ding' | 'whoosh' | 'pop' | 'bass_drop' | 'applause', audioSettings.sfxVolume)}
                  className="py-2.5 px-2 bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/40 rounded-xl text-xs font-bold text-slate-200 transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Play className="w-3 h-3 text-amber-400" />
                  <span>{sfx.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Background Music & Audio Mixing Sliders (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Multi-Track Volume Mixer */}
          <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <Sliders className="w-4 h-4 text-emerald-400" />
                <span>3. Bàn Trộn Đa Luồng (Audio Mixer)</span>
              </div>
              <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                100% Không Câm Tiếng
              </span>
            </div>

            {/* Video Original Volume */}
            <div className="space-y-2 bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <div className="flex justify-between text-xs font-bold text-slate-200">
                <span>Âm thanh video gốc</span>
                <span className="font-mono text-indigo-400">{Math.round(audioSettings.originalVideoVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="2.0"
                step="0.05"
                value={audioSettings.originalVideoVolume}
                onChange={(e) => onChangeAudio({ ...audioSettings, originalVideoVolume: parseFloat(e.target.value) })}
                className="w-full accent-indigo-500"
              />
            </div>

            {/* BGM Volume */}
            <div className="space-y-2 bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <div className="flex justify-between text-xs font-bold text-slate-200">
                <span>Nhạc nền BGM</span>
                <span className="font-mono text-emerald-400">{Math.round(audioSettings.bgmVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1.5"
                step="0.05"
                value={audioSettings.bgmVolume}
                onChange={(e) => onChangeAudio({ ...audioSettings, bgmVolume: parseFloat(e.target.value) })}
                className="w-full accent-emerald-500"
              />
            </div>

            {/* Voiceover Volume */}
            <div className="space-y-2 bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <div className="flex justify-between text-xs font-bold text-slate-200">
                <span>Giọng đọc thuyết minh</span>
                <span className="font-mono text-amber-400">{Math.round(audioSettings.voiceoverVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="2.0"
                step="0.05"
                value={audioSettings.voiceoverVolume}
                onChange={(e) => onChangeAudio({ ...audioSettings, voiceoverVolume: parseFloat(e.target.value) })}
                className="w-full accent-amber-500"
              />
            </div>
          </div>

          {/* Background Music Selector */}
          <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center gap-2 text-sm font-bold text-white">
              <Music className="w-4 h-4 text-purple-400" />
              <span>4. Chọn Nhạc Nền (BGM)</span>
            </div>

            <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
              {BGM_TRACKS.map((track) => {
                const isSelected = audioSettings.bgmTrackId === track.id;
                const isPlaying = isPlayingBgm === track.id;

                return (
                  <div
                    key={track.id}
                    className={`p-3 rounded-xl border transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-purple-950/40 border-purple-500/50 ring-1 ring-purple-500/30'
                        : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div
                      onClick={() => onChangeAudio({ ...audioSettings, bgmTrackId: track.id, bgmTitle: track.name })}
                      className="flex-1 cursor-pointer"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{track.name}</span>
                        <span className="text-[10px] text-slate-400 font-medium px-1.5 py-0.5 bg-slate-900 rounded">
                          {track.genre}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">{track.description}</p>
                    </div>

                    {track.id !== 'none' && track.id !== 'custom' && (
                      <button
                        onClick={() => handleToggleBgm(track.id)}
                        className={`p-2 rounded-lg transition-all ml-2 cursor-pointer ${
                          isPlaying
                            ? 'bg-rose-600 text-white'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                        }`}
                        title={isPlaying ? 'Dừng phát' : 'Nghe thử'}
                      >
                        {isPlaying ? <Square className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
