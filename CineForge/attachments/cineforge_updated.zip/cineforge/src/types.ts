export type StepId = 'IMPORT' | 'DECISION' | 'EDIT' | 'EXPORT' | 'PYTHON_PIPELINE';

export interface VideoItem {
  id: string;
  title: string;
  url: string;
  thumbnail: string;
  duration: number; // in seconds
  source: 'search' | 'url' | 'upload' | 'sample';
  category: string;
  resolution: string;
  aspectRatio: '16:9' | '9:16' | '1:1';
  author: string;
  views?: string;
}

export interface AudioSettings {
  // Volume controls (0 to 2.0 where 1.0 is 100%)
  originalVideoVolume: number;
  bgmVolume: number;
  voiceoverVolume: number;
  sfxVolume: number;

  // Audio sources
  enableOriginalAudio: boolean;
  bgmTrackId: string; // 'none', 'lofi', 'cinematic', 'upbeat', 'vlog', 'dramatic', 'chill', 'custom'
  bgmTitle: string;
  bgmCustomUrl?: string;
  bgmCustomName?: string;

  // Voiceover / TTS
  enableVoiceover: boolean;
  voiceoverText: string;
  voiceoverLang: string; // 'vi-VN', 'en-US'
  voiceoverAccent: 'north' | 'south' | 'central' | 'natural';
  voiceoverPitch: number; // 0.5 - 1.5
  voiceoverSpeed: number; // 0.7 - 1.5

  // Audio features
  autoDucking: boolean; // Auto-duck background music during voiceover
  normalizeAudio: boolean;
  sampleRate: 44100 | 48000;
  audioBitrate: string; // '192k'
}

export interface VideoEditSettings {
  trimStart: number;
  trimEnd: number;
  colorFilter: 'normal' | 'cinematic' | 'vibrant' | 'vintage' | 'bw' | 'cyberpunk' | 'warm';
  brightness: number; // 0.5 - 1.5
  contrast: number; // 0.5 - 1.5
  saturation: number; // 0 - 2.0
  playbackSpeed: number; // 0.5, 0.75, 1, 1.25, 1.5, 2

  // Text Overlay & Subtitles
  overlayText: string;
  textPosition: 'top' | 'center' | 'bottom';
  textColor: string;
  textBgColor: string;
  textSize: number;
  enableSubtitles: boolean;
  subtitlesScript: string;
  aspectRatio: '16:9' | '9:16' | '1:1' | '4:5';

  // Brand Name Watermarks
  brandName1: string; // Góc trái trên, cỡ chữ 20px, cố định
  enableBrandName1: boolean;
  brandName2: string; // Chạy khắp video, cỡ chữ 13px, độ mờ 15%
  enableBrandName2: boolean;
}

export interface RenderResult {
  isRendering: boolean;
  progress: number;
  statusMessage: string;
  exportedUrl: string | null;
  exportedBlob: Blob | null;
  exportedFilename: string;
  exportedDuration: number;
  exportedSize: string;
  hasAudio: boolean;
  audioDetails: string;
  error?: string | null;
}
